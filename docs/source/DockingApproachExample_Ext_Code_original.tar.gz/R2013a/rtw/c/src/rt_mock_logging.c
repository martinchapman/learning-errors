#include "rtwtypes.h"

const char_T *rt_UpdateTXYLogVars(RTWLogInfo *li, time_T *tPtr) { return 0; }
void rt_UpdateSigLogVars(RTWLogInfo *li, time_T *tPtr) { }
const char_T *rt_StartDataLogging(RTWLogInfo *li, const real_T finalTime, const real_T stepSize, const char_T **errStatus) { return 0; }
void rt_StopDataLogging(const char_T *file, RTWLogInfo *li) { }
