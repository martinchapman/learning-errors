/*
 * DockingApproachExample_Ext.c
 *
 * Code generation for model "DockingApproachExample_Ext".
 *
 * Model version              : 1.484
 * Simulink Coder version : 8.4 (R2013a) 13-Feb-2013
 * C source code generated on : Fri Dec 19 09:13:53 2014
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objective: Execution efficiency
 * Validation result: Not run
 */
#include "DockingApproachExample_Ext.h"
#include "DockingApproachExample_Ext_private.h"

/* Named constants for Chart: '<Root>/Chart' */
#define CaptureApproach_timer_upper_lim ((int8_T)11)
#define D_IN_CollisionAvoidanceManuever ((uint8_T)3U)
#define D_IN_OrientedForDockingApproach ((uint8_T)4U)
#define Doc_IN_CheckTargetRelativeState ((uint8_T)1U)
#define Dockin_IN_CaptureApproachFailed ((uint8_T)1U)
#define Dockin_IN_DockingApproachFailed ((uint8_T)3U)
#define DockingA_IN_ProximityOperations ((uint8_T)11U)
#define DockingAp_GPS_timer_upper_limit ((int8_T)6)
#define DockingApp_IN_CheckOrbitalState ((uint8_T)2U)
#define DockingAppr_IN_ClosedButUnmated ((uint8_T)1U)
#define DockingAppro_IN_CaptureApproach ((uint8_T)2U)
#define DockingAppro_IN_CheckLatchMated ((uint8_T)1U)
#define DockingAppro_IN_ComputeThrust_d ((uint8_T)3U)
#define DockingAppro_IN_DockingApproach ((uint8_T)5U)
#define DockingAppro_IN_NO_ACTIVE_CHILD ((uint8_T)0U)
#define DockingApproa_IN_CheckLatchOpen ((uint8_T)2U)
#define DockingApproa_IN_FailedApproach ((uint8_T)6U)
#define DockingApproa_IN_JointStabilize ((uint8_T)9U)
#define DockingApproac_CLOSEDBUTUNMATED ((int8_T)2)
#define DockingApproac_IN_ApproachOrbit ((uint8_T)1U)
#define DockingApproac_IN_ComputeThrust ((uint8_T)2U)
#define DockingApproac_IN_StartApproach ((uint8_T)5U)
#define DockingApproac_event_callibrate (0)
#define DockingApproachE_IN_FarApproach ((uint8_T)7U)
#define DockingApproachE_IN_LatchFailed ((uint8_T)4U)
#define DockingApproachE_IN_ReadyToDock ((uint8_T)4U)
#define DockingApproachEx_INDETERMINATE ((int8_T)0)
#define DockingApproachExa_IN_ACQUIRING ((uint8_T)1U)
#define DockingApproachExa_IN_Acquiring ((uint8_T)1U)
#define DockingApproachExa_IN_Disengage ((uint8_T)4U)
#define DockingApproachExamp_CALL_EVENT (-1)
#define DockingApproachExamp_IN_Closing ((uint8_T)2U)
#define DockingApproachExamp_IN_Opening ((uint8_T)5U)
#define DockingApproachExampl_IN_Docked ((uint8_T)3U)
#define DockingApproachExampl_IN_GOOD_p ((uint8_T)1U)
#define DockingApproachExampl_IN_POOR_g ((uint8_T)2U)
#define DockingApproachExampl_IN_pvGOOD ((uint8_T)4U)
#define DockingApproachExample_Ex_EXIST (TRUE)
#define DockingApproachExample_Ex_MATED ((int8_T)3)
#define DockingApproachExample_Ext_GOOD ((int8_T)2)
#define DockingApproachExample_Ext_NONE ((int8_T)0)
#define DockingApproachExample_Ext_OPEN ((int8_T)1)
#define DockingApproachExample_Ext_POOR ((int8_T)1)
#define DockingApproachExample_IN_Mated ((uint8_T)3U)
#define DockingApproachExample_IN_Start ((uint8_T)12U)
#define DockingApproachExample__IN_GOOD ((uint8_T)2U)
#define DockingApproachExample__IN_Good ((uint8_T)2U)
#define DockingApproachExample__IN_Open ((uint8_T)4U)
#define DockingApproachExample__IN_POOR ((uint8_T)3U)
#define DockingApproachExample__IN_Poor ((uint8_T)3U)
#define DockingApproach_IN_JointMission ((uint8_T)8U)
#define DockingApproach_IN_LatchCapture ((uint8_T)10U)
#define DockingApproach_timer_upper_lim ((int8_T)9)
#define InertialNavigation_timer_upper_ ((int8_T)6)
#define LatchCapture_timer_upper_limit ((int8_T)8)
#define StarPlanetTracker_timer_upper_l ((int8_T)6)
#define dockingSensor_timer_upper_limit ((int8_T)6)

/* Block states (auto storage) */
DW_DockingApproachExample_Ext_T DockingApproachExample_Ext_DW;

/* External inputs (root inport signals with auto storage) */
ExtU_DockingApproachExample_E_T DockingApproachExample_Ext_U;

/* External outputs (root outports fed by signals with auto storage) */
ExtY_DockingApproachExample_E_T DockingApproachExample_Ext_Y;

/* Real-time model */
RT_MODEL_DockingApproachExamp_T DockingApproachExample_Ext_M_;
RT_MODEL_DockingApproachExamp_T *const DockingApproachExample_Ext_M =
  &DockingApproachExample_Ext_M_;

/* Forward declaration for local functions */
static void D_exit_internal_CaptureApproach(void);
static void DockingAppro_InertialNavigation(void);
static void DockingAppr_OrbitalState_Active(void);
static void D_exit_internal_DockingApproach(void);
static void enter_internal_OrbitalState_Act(void);
static void DockingApproach_DockingApproach(void);
static void DockingAppro_MissionPhaseStates(void);

/* Function for Chart: '<Root>/Chart' */
static void D_exit_internal_CaptureApproach(void)
{
  /* Exit Internal 'CaptureApproach': '<S1>:283' */
  /* Exit Internal 'OrbitalState_Active': '<S1>:307' */
  /* Exit Internal 'InertialNavigation': '<S1>:366' */
  DockingApproachExample_Ext_DW.is_InertialNavigation =
    DockingAppro_IN_NO_ACTIVE_CHILD;
  DockingApproachExample_Ext_DW.is_active_InertialNavigation = 0U;

  /* Exit Internal 'StarPlanetTracker': '<S1>:353' */
  DockingApproachExample_Ext_DW.is_StarPlanetTracker =
    DockingAppro_IN_NO_ACTIVE_CHILD;
  DockingApproachExample_Ext_DW.is_active_StarPlanetTracker = 0U;

  /* Exit Internal 'GPS': '<S1>:341' */
  DockingApproachExample_Ext_DW.is_GPS = DockingAppro_IN_NO_ACTIVE_CHILD;
  DockingApproachExample_Ext_DW.is_active_GPS = 0U;

  /* Exit Internal 'OrbitalState_Complex': '<S1>:308' */
  /* Exit Internal 'OrbitalState2': '<S1>:334' */
  DockingApproachExample_Ext_DW.is_OrbitalState2 =
    DockingAppro_IN_NO_ACTIVE_CHILD;
  DockingApproachExample_Ext_DW.is_active_OrbitalState2 = 0U;

  /* Exit Internal 'OrbitalState': '<S1>:309' */
  DockingApproachExample_Ext_DW.is_OrbitalState =
    DockingAppro_IN_NO_ACTIVE_CHILD;
  DockingApproachExample_Ext_DW.is_active_OrbitalState = 0U;
  DockingApproachExample_Ext_DW.is_active_OrbitalState_Complex = 0U;
  DockingApproachExample_Ext_DW.is_active_OrbitalState_Active = 0U;

  /* Exit Internal 'CaptureApproach': '<S1>:287' */
  if (DockingApproachExample_Ext_DW.is_CaptureApproach ==
      D_IN_OrientedForDockingApproach) {
    /* Exit 'OrientedForDockingApproach': '<S1>:304' */
    DockingApproachExample_Ext_Y.CaptureApproachComplete = TRUE;
    DockingApproachExample_Ext_DW.is_CaptureApproach =
      DockingAppro_IN_NO_ACTIVE_CHILD;
  } else {
    DockingApproachExample_Ext_DW.is_CaptureApproach =
      DockingAppro_IN_NO_ACTIVE_CHILD;
  }

  DockingApproachExample_Ext_DW.is_active_CaptureApproach = 0U;
}

/* Function for Chart: '<Root>/Chart' */
static void DockingAppro_InertialNavigation(void)
{
  int32_T u;

  /* During 'InertialNavigation': '<S1>:366' */
  /* 6 */
  u = DockingApproachExample_Ext_DW.InertialNavigation_timer + 1;
  if (u <= 6) {
    DockingApproachExample_Ext_DW.InertialNavigation_timer = (int8_T)u;
  } else {
    DockingApproachExample_Ext_DW.InertialNavigation_timer = 6;
  }

  switch (DockingApproachExample_Ext_DW.is_InertialNavigation) {
   case DockingApproachExa_IN_ACQUIRING:
    /* During 'ACQUIRING': '<S1>:376' */
    if (DockingApproachExample_Ext_DW.sfEvent == DockingApproac_event_callibrate)
    {
      /* Transition: '<S1>:369' */
      DockingApproachExample_Ext_DW.is_InertialNavigation =
        DockingApproachExample__IN_GOOD;

      /* Entry 'GOOD': '<S1>:377' */
      DockingApproachExample_Ext_DW.InertialNavigation_timer = 0;
      DockingApproachExample_Ext_DW.InertialNavigation_AbsolutePosi =
        DockingApproachExample_Ext_GOOD;
      DockingApproachExample_Ext_DW.InertialNavigation_AbsoluteVelo =
        DockingApproachExample_Ext_GOOD;
      DockingApproachExample_Ext_DW.InertialNavigation_AbsoluteAtti =
        DockingApproachExample_Ext_GOOD;
    }
    break;

   case DockingApproachExample__IN_GOOD:
    /* During 'GOOD': '<S1>:377' */
    /* 6 */
    if (DockingApproachExample_Ext_DW.InertialNavigation_timer ==
        InertialNavigation_timer_upper_) {
      /* Transition: '<S1>:375' */
      DockingApproachExample_Ext_DW.is_InertialNavigation =
        DockingApproachExample__IN_POOR;

      /* Entry 'POOR': '<S1>:378' */
      DockingApproachExample_Ext_DW.InertialNavigation_AbsolutePosi =
        DockingApproachExample_Ext_POOR;
      DockingApproachExample_Ext_DW.InertialNavigation_AbsoluteVelo =
        DockingApproachExample_Ext_POOR;
      DockingApproachExample_Ext_DW.InertialNavigation_AbsoluteAtti =
        DockingApproachExample_Ext_POOR;
    } else {
      /* 6 */
      if (DockingApproachExample_Ext_DW.InertialNavigation_timer <
          InertialNavigation_timer_upper_) {
        /* Transition: '<S1>:373' */
        DockingApproachExample_Ext_DW.is_InertialNavigation =
          DockingApproachExample__IN_GOOD;

        /* Entry 'GOOD': '<S1>:377' */
        DockingApproachExample_Ext_DW.InertialNavigation_timer = 0;
        DockingApproachExample_Ext_DW.InertialNavigation_AbsolutePosi =
          DockingApproachExample_Ext_GOOD;
        DockingApproachExample_Ext_DW.InertialNavigation_AbsoluteVelo =
          DockingApproachExample_Ext_GOOD;
        DockingApproachExample_Ext_DW.InertialNavigation_AbsoluteAtti =
          DockingApproachExample_Ext_GOOD;
      } else {
        /* Transition: '<S1>:372' */
        if (DockingApproachExample_Ext_U.InertialNavigation_time !=
            DockingApproachExample_Ext_DW.VALID) {
          /* Transition: '<S1>:370' */
          DockingApproachExample_Ext_DW.is_InertialNavigation =
            DockingApproachExa_IN_ACQUIRING;

          /* Entry 'ACQUIRING': '<S1>:376' */
          DockingApproachExample_Ext_DW.InertialNavigation_AbsolutePosi =
            DockingApproachExample_Ext_NONE;
          DockingApproachExample_Ext_DW.InertialNavigation_AbsoluteVelo =
            DockingApproachExample_Ext_NONE;
          DockingApproachExample_Ext_DW.InertialNavigation_AbsoluteAtti =
            DockingApproachExample_Ext_NONE;
        }
      }
    }
    break;

   case DockingApproachExample__IN_POOR:
    /* During 'POOR': '<S1>:378' */
    if (DockingApproachExample_Ext_DW.sfEvent == DockingApproac_event_callibrate)
    {
      /* Transition: '<S1>:374' */
      DockingApproachExample_Ext_DW.is_InertialNavigation =
        DockingApproachExample__IN_GOOD;

      /* Entry 'GOOD': '<S1>:377' */
      DockingApproachExample_Ext_DW.InertialNavigation_timer = 0;
      DockingApproachExample_Ext_DW.InertialNavigation_AbsolutePosi =
        DockingApproachExample_Ext_GOOD;
      DockingApproachExample_Ext_DW.InertialNavigation_AbsoluteVelo =
        DockingApproachExample_Ext_GOOD;
      DockingApproachExample_Ext_DW.InertialNavigation_AbsoluteAtti =
        DockingApproachExample_Ext_GOOD;
    } else {
      /* Transition: '<S1>:371' */
      if (DockingApproachExample_Ext_U.InertialNavigation_time !=
          DockingApproachExample_Ext_DW.VALID) {
        /* Transition: '<S1>:370' */
        DockingApproachExample_Ext_DW.is_InertialNavigation =
          DockingApproachExa_IN_ACQUIRING;

        /* Entry 'ACQUIRING': '<S1>:376' */
        DockingApproachExample_Ext_DW.InertialNavigation_AbsolutePosi =
          DockingApproachExample_Ext_NONE;
        DockingApproachExample_Ext_DW.InertialNavigation_AbsoluteVelo =
          DockingApproachExample_Ext_NONE;
        DockingApproachExample_Ext_DW.InertialNavigation_AbsoluteAtti =
          DockingApproachExample_Ext_NONE;
      }
    }
    break;

   default:
    DockingApproachExample_Ext_DW.is_InertialNavigation =
      DockingAppro_IN_NO_ACTIVE_CHILD;
    break;
  }
}

/* Function for Chart: '<Root>/Chart' */
static void DockingAppr_OrbitalState_Active(void)
{
  int32_T b_previousEvent;

  /* During 'OrbitalState_Active': '<S1>:307' */
  if (DockingApproachExample_Ext_DW.is_active_OrbitalState_Complex != 0U) {
    /* During 'OrbitalState_Complex': '<S1>:308' */
    if (DockingApproachExample_Ext_DW.is_active_OrbitalState != 0U) {
      /* During 'OrbitalState': '<S1>:309' */
      switch (DockingApproachExample_Ext_DW.is_OrbitalState) {
       case DockingApproachExa_IN_Acquiring:
        /* During 'Acquiring': '<S1>:326' */
        if ((!((DockingApproachExample_Ext_DW.GPS_AbsolutePosition ==
                DockingApproachExample_Ext_NONE) &&
               (DockingApproachExample_Ext_DW.StarPlanetTracker_AbsolutePosit ==
                DockingApproachExample_Ext_NONE) &&
               (DockingApproachExample_Ext_U.GroundTrack_OrbitalPosition ==
                DockingApproachExample_Ext_NONE))) &&
            (!((DockingApproachExample_Ext_DW.GPS_AbsoluteVelocity ==
                DockingApproachExample_Ext_NONE) &&
               (DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteVeloc ==
                DockingApproachExample_Ext_NONE) &&
               (DockingApproachExample_Ext_U.GroundTrack_OrbitalVelocity ==
                DockingApproachExample_Ext_NONE)))) {
          /* Transition: '<S1>:317' */
          DockingApproachExample_Ext_DW.is_OrbitalState =
            DockingApproachExample__IN_POOR;

          /* Entry 'POOR': '<S1>:327' */
          DockingApproachExample_Ext_DW.OrbitalState_Position =
            DockingApproachExample_Ext_POOR;
          DockingApproachExample_Ext_DW.OrbitalState_Velocity =
            DockingApproachExample_Ext_POOR;
          DockingApproachExample_Ext_DW.OrbitalState_Attitude =
            DockingApproachExample_Ext_NONE;
        } else {
          if ((DockingApproachExample_Ext_DW.GPS_AbsolutePosition ==
               DockingApproachExample_Ext_NONE) &&
              (DockingApproachExample_Ext_DW.GPS_AbsoluteVelocity ==
               DockingApproachExample_Ext_NONE) &&
              (DockingApproachExample_Ext_DW.StarPlanetTracker_AbsolutePosit ==
               DockingApproachExample_Ext_NONE) &&
              (DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteVeloc ==
               DockingApproachExample_Ext_NONE) &&
              (DockingApproachExample_Ext_U.GroundTrack_OrbitalPosition ==
               DockingApproachExample_Ext_NONE) &&
              (DockingApproachExample_Ext_U.GroundTrack_OrbitalVelocity ==
               DockingApproachExample_Ext_NONE)) {
            /* Transition: '<S1>:314' */
            DockingApproachExample_Ext_DW.is_OrbitalState =
              DockingApproachExa_IN_Acquiring;

            /* Entry 'Acquiring': '<S1>:326' */
            DockingApproachExample_Ext_DW.OrbitalState_Position =
              DockingApproachExample_Ext_NONE;
            DockingApproachExample_Ext_DW.OrbitalState_Velocity =
              DockingApproachExample_Ext_NONE;
            DockingApproachExample_Ext_DW.OrbitalState_Attitude =
              DockingApproachExample_Ext_NONE;
          }
        }
        break;

       case DockingApproachExample__IN_GOOD:
        /* During 'GOOD': '<S1>:329' */
        if ((!(((DockingApproachExample_Ext_U.GroundTrack_OrbitalPosition ==
                 DockingApproachExample_Ext_GOOD) &&
                (DockingApproachExample_Ext_DW.GPS_AbsolutePosition ==
                 DockingApproachExample_Ext_GOOD)) ||
               ((DockingApproachExample_Ext_U.GroundTrack_OrbitalPosition ==
                 DockingApproachExample_Ext_GOOD) &&
                (DockingApproachExample_Ext_DW.StarPlanetTracker_AbsolutePosit ==
                 DockingApproachExample_Ext_GOOD)) ||
               ((DockingApproachExample_Ext_DW.StarPlanetTracker_AbsolutePosit ==
                 DockingApproachExample_Ext_GOOD) &&
                (DockingApproachExample_Ext_DW.GPS_AbsolutePosition ==
                 DockingApproachExample_Ext_GOOD)) ||
               ((DockingApproachExample_Ext_DW.InertialNavigation_AbsolutePosi ==
                 DockingApproachExample_Ext_GOOD) &&
                (DockingApproachExample_Ext_U.GroundTrack_OrbitalPosition ==
                 DockingApproachExample_Ext_GOOD)) ||
               ((DockingApproachExample_Ext_DW.InertialNavigation_AbsolutePosi ==
                 DockingApproachExample_Ext_GOOD) &&
                (DockingApproachExample_Ext_DW.GPS_AbsolutePosition ==
                 DockingApproachExample_Ext_GOOD)) ||
               ((DockingApproachExample_Ext_DW.InertialNavigation_AbsolutePosi ==
                 DockingApproachExample_Ext_GOOD) &&
                (DockingApproachExample_Ext_DW.StarPlanetTracker_AbsolutePosit ==
                 DockingApproachExample_Ext_GOOD)))) &&
            (!((DockingApproachExample_Ext_DW.InertialNavigation_AbsoluteAtti ==
                DockingApproachExample_Ext_GOOD) ||
               (DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteAttit ==
                DockingApproachExample_Ext_GOOD))) &&
            (!(((DockingApproachExample_Ext_U.GroundTrack_OrbitalVelocity ==
                 DockingApproachExample_Ext_GOOD) &&
                (DockingApproachExample_Ext_DW.GPS_AbsoluteVelocity ==
                 DockingApproachExample_Ext_GOOD)) ||
               ((DockingApproachExample_Ext_U.GroundTrack_OrbitalVelocity ==
                 DockingApproachExample_Ext_GOOD) &&
                (DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteVeloc ==
                 DockingApproachExample_Ext_GOOD)) ||
               ((DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteVeloc ==
                 DockingApproachExample_Ext_GOOD) &&
                (DockingApproachExample_Ext_DW.GPS_AbsoluteVelocity ==
                 DockingApproachExample_Ext_GOOD)) ||
               ((DockingApproachExample_Ext_DW.InertialNavigation_AbsoluteVelo ==
                 DockingApproachExample_Ext_GOOD) &&
                (DockingApproachExample_Ext_U.GroundTrack_OrbitalVelocity ==
                 DockingApproachExample_Ext_GOOD)) ||
               ((DockingApproachExample_Ext_DW.InertialNavigation_AbsoluteVelo ==
                 DockingApproachExample_Ext_GOOD) &&
                (DockingApproachExample_Ext_DW.GPS_AbsoluteVelocity ==
                 DockingApproachExample_Ext_GOOD)) ||
               ((DockingApproachExample_Ext_DW.InertialNavigation_AbsoluteVelo ==
                 DockingApproachExample_Ext_GOOD) &&
                (DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteVeloc ==
                 DockingApproachExample_Ext_GOOD))))) {
          /* Transition: '<S1>:323' */
          /* Transition: '<S1>:321' */
          /* Transition: '<S1>:319' */
          DockingApproachExample_Ext_DW.is_OrbitalState =
            DockingApproachExample__IN_POOR;

          /* Entry 'POOR': '<S1>:327' */
          DockingApproachExample_Ext_DW.OrbitalState_Position =
            DockingApproachExample_Ext_POOR;
          DockingApproachExample_Ext_DW.OrbitalState_Velocity =
            DockingApproachExample_Ext_POOR;
          DockingApproachExample_Ext_DW.OrbitalState_Attitude =
            DockingApproachExample_Ext_NONE;
        } else {
          if (((DockingApproachExample_Ext_U.GroundTrack_OrbitalPosition ==
                DockingApproachExample_Ext_GOOD) ||
               (DockingApproachExample_Ext_DW.GPS_AbsolutePosition ==
                DockingApproachExample_Ext_GOOD) ||
               (DockingApproachExample_Ext_DW.StarPlanetTracker_AbsolutePosit ==
                DockingApproachExample_Ext_GOOD)) &&
              ((DockingApproachExample_Ext_U.GroundTrack_OrbitalVelocity ==
                DockingApproachExample_Ext_GOOD) ||
               (DockingApproachExample_Ext_DW.GPS_AbsoluteVelocity ==
                DockingApproachExample_Ext_GOOD) ||
               (DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteVeloc ==
                DockingApproachExample_Ext_GOOD)) &&
              (DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteAttit ==
               DockingApproachExample_Ext_GOOD)) {
            /* Transition: '<S1>:325' */
            DockingApproachExample_Ext_DW.is_OrbitalState =
              DockingAppro_IN_NO_ACTIVE_CHILD;
            b_previousEvent = DockingApproachExample_Ext_DW.sfEvent;
            DockingApproachExample_Ext_DW.sfEvent =
              DockingApproac_event_callibrate;
            if (DockingApproachExample_Ext_DW.is_active_InertialNavigation != 0U)
            {
              DockingAppro_InertialNavigation();
            }

            DockingApproachExample_Ext_DW.sfEvent = b_previousEvent;
            DockingApproachExample_Ext_DW.is_OrbitalState =
              DockingApproachExample__IN_GOOD;

            /* Entry 'GOOD': '<S1>:329' */
            DockingApproachExample_Ext_DW.OrbitalState_Position =
              DockingApproachExample_Ext_GOOD;
            DockingApproachExample_Ext_DW.OrbitalState_Velocity =
              DockingApproachExample_Ext_GOOD;
            DockingApproachExample_Ext_DW.OrbitalState_Attitude =
              DockingApproachExample_Ext_GOOD;
          }
        }
        break;

       case DockingApproachExample__IN_POOR:
        /* During 'POOR': '<S1>:327' */
        if ((DockingApproachExample_Ext_U.GroundTrack_OrbitalPosition ==
             DockingApproachExample_Ext_NONE) &&
            (DockingApproachExample_Ext_DW.GPS_AbsolutePosition ==
             DockingApproachExample_Ext_NONE) &&
            (DockingApproachExample_Ext_DW.StarPlanetTracker_AbsolutePosit ==
             DockingApproachExample_Ext_NONE) &&
            ((DockingApproachExample_Ext_U.GroundTrack_OrbitalVelocity ==
              DockingApproachExample_Ext_NONE) &&
             (DockingApproachExample_Ext_DW.GPS_AbsoluteVelocity ==
              DockingApproachExample_Ext_NONE) &&
             (DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteVeloc ==
              DockingApproachExample_Ext_NONE))) {
          /* Transition: '<S1>:316' */
          DockingApproachExample_Ext_DW.is_OrbitalState =
            DockingApproachExa_IN_Acquiring;

          /* Entry 'Acquiring': '<S1>:326' */
          DockingApproachExample_Ext_DW.OrbitalState_Position =
            DockingApproachExample_Ext_NONE;
          DockingApproachExample_Ext_DW.OrbitalState_Velocity =
            DockingApproachExample_Ext_NONE;
          DockingApproachExample_Ext_DW.OrbitalState_Attitude =
            DockingApproachExample_Ext_NONE;
        } else {
          if ((((DockingApproachExample_Ext_U.GroundTrack_OrbitalPosition ==
                 DockingApproachExample_Ext_GOOD) &&
                (DockingApproachExample_Ext_DW.GPS_AbsolutePosition ==
                 DockingApproachExample_Ext_GOOD)) ||
               ((DockingApproachExample_Ext_U.GroundTrack_OrbitalPosition ==
                 DockingApproachExample_Ext_GOOD) &&
                (DockingApproachExample_Ext_DW.StarPlanetTracker_AbsolutePosit ==
                 DockingApproachExample_Ext_GOOD)) ||
               ((DockingApproachExample_Ext_DW.StarPlanetTracker_AbsolutePosit ==
                 DockingApproachExample_Ext_GOOD) &&
                (DockingApproachExample_Ext_DW.GPS_AbsolutePosition ==
                 DockingApproachExample_Ext_GOOD)) ||
               ((DockingApproachExample_Ext_DW.InertialNavigation_AbsolutePosi ==
                 DockingApproachExample_Ext_GOOD) &&
                (DockingApproachExample_Ext_U.GroundTrack_OrbitalPosition ==
                 DockingApproachExample_Ext_GOOD)) ||
               ((DockingApproachExample_Ext_DW.InertialNavigation_AbsolutePosi ==
                 DockingApproachExample_Ext_GOOD) &&
                (DockingApproachExample_Ext_DW.GPS_AbsolutePosition ==
                 DockingApproachExample_Ext_GOOD)) ||
               ((DockingApproachExample_Ext_DW.InertialNavigation_AbsolutePosi ==
                 DockingApproachExample_Ext_GOOD) &&
                (DockingApproachExample_Ext_DW.StarPlanetTracker_AbsolutePosit ==
                 DockingApproachExample_Ext_GOOD))) &&
              (((DockingApproachExample_Ext_U.GroundTrack_OrbitalVelocity ==
                 DockingApproachExample_Ext_GOOD) &&
                (DockingApproachExample_Ext_DW.GPS_AbsoluteVelocity ==
                 DockingApproachExample_Ext_GOOD)) ||
               ((DockingApproachExample_Ext_U.GroundTrack_OrbitalVelocity ==
                 DockingApproachExample_Ext_GOOD) &&
                (DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteVeloc ==
                 DockingApproachExample_Ext_GOOD)) ||
               ((DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteVeloc ==
                 DockingApproachExample_Ext_GOOD) &&
                (DockingApproachExample_Ext_DW.GPS_AbsoluteVelocity ==
                 DockingApproachExample_Ext_GOOD)) ||
               ((DockingApproachExample_Ext_DW.InertialNavigation_AbsoluteVelo ==
                 DockingApproachExample_Ext_GOOD) &&
                (DockingApproachExample_Ext_U.GroundTrack_OrbitalVelocity ==
                 DockingApproachExample_Ext_GOOD)) ||
               ((DockingApproachExample_Ext_DW.InertialNavigation_AbsoluteVelo ==
                 DockingApproachExample_Ext_GOOD) &&
                (DockingApproachExample_Ext_DW.GPS_AbsoluteVelocity ==
                 DockingApproachExample_Ext_GOOD)) ||
               ((DockingApproachExample_Ext_DW.InertialNavigation_AbsoluteVelo ==
                 DockingApproachExample_Ext_GOOD) &&
                (DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteVeloc ==
                 DockingApproachExample_Ext_GOOD))) &&
              ((DockingApproachExample_Ext_DW.InertialNavigation_AbsoluteAtti ==
                DockingApproachExample_Ext_GOOD) ||
               (DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteAttit ==
                DockingApproachExample_Ext_GOOD))) {
            /* Transition: '<S1>:318' */
            /* Transition: '<S1>:320' */
            /* Transition: '<S1>:322' */
            DockingApproachExample_Ext_DW.is_OrbitalState =
              DockingApproachExampl_IN_pvGOOD;

            /* Entry 'pvGOOD': '<S1>:328' */
            DockingApproachExample_Ext_DW.OrbitalState_Position =
              DockingApproachExample_Ext_GOOD;
            DockingApproachExample_Ext_DW.OrbitalState_Velocity =
              DockingApproachExample_Ext_GOOD;
            DockingApproachExample_Ext_DW.OrbitalState_Attitude =
              DockingApproachExample_Ext_POOR;
          }
        }
        break;

       case DockingApproachExampl_IN_pvGOOD:
        /* During 'pvGOOD': '<S1>:328' */
        if (((DockingApproachExample_Ext_U.GroundTrack_OrbitalPosition ==
              DockingApproachExample_Ext_GOOD) ||
             (DockingApproachExample_Ext_DW.GPS_AbsolutePosition ==
              DockingApproachExample_Ext_GOOD) ||
             (DockingApproachExample_Ext_DW.StarPlanetTracker_AbsolutePosit ==
              DockingApproachExample_Ext_GOOD)) &&
            ((DockingApproachExample_Ext_U.GroundTrack_OrbitalVelocity ==
              DockingApproachExample_Ext_GOOD) ||
             (DockingApproachExample_Ext_DW.GPS_AbsoluteVelocity ==
              DockingApproachExample_Ext_GOOD) ||
             (DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteVeloc ==
              DockingApproachExample_Ext_GOOD)) &&
            (DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteAttit ==
             DockingApproachExample_Ext_GOOD)) {
          /* Transition: '<S1>:324' */
          DockingApproachExample_Ext_DW.is_OrbitalState =
            DockingAppro_IN_NO_ACTIVE_CHILD;
          b_previousEvent = DockingApproachExample_Ext_DW.sfEvent;
          DockingApproachExample_Ext_DW.sfEvent =
            DockingApproac_event_callibrate;
          if (DockingApproachExample_Ext_DW.is_active_InertialNavigation != 0U)
          {
            DockingAppro_InertialNavigation();
          }

          DockingApproachExample_Ext_DW.sfEvent = b_previousEvent;
          DockingApproachExample_Ext_DW.is_OrbitalState =
            DockingApproachExample__IN_GOOD;

          /* Entry 'GOOD': '<S1>:329' */
          DockingApproachExample_Ext_DW.OrbitalState_Position =
            DockingApproachExample_Ext_GOOD;
          DockingApproachExample_Ext_DW.OrbitalState_Velocity =
            DockingApproachExample_Ext_GOOD;
          DockingApproachExample_Ext_DW.OrbitalState_Attitude =
            DockingApproachExample_Ext_GOOD;
        }
        break;

       default:
        DockingApproachExample_Ext_DW.is_OrbitalState =
          DockingAppro_IN_NO_ACTIVE_CHILD;
        break;
      }
    }

    if (DockingApproachExample_Ext_DW.is_active_OrbitalState2 != 0U) {
      /* During 'OrbitalState2': '<S1>:334' */
      switch (DockingApproachExample_Ext_DW.is_OrbitalState2) {
       case DockingApproachExampl_IN_GOOD_p:
        /* During 'GOOD': '<S1>:340' */
        if (DockingApproachExample_Ext_U.RealTimeClock_time !=
            DockingApproachExample_Ext_GOOD) {
          /* Transition: '<S1>:336' */
          DockingApproachExample_Ext_DW.is_OrbitalState2 =
            DockingApproachExampl_IN_POOR_g;

          /* Entry 'POOR': '<S1>:339' */
          DockingApproachExample_Ext_DW.OrbitalState_Time =
            DockingApproachExample_Ext_POOR;
        } else {
          if ((DockingApproachExample_Ext_U.GroundTrack_Time ==
               DockingApproachExample_Ext_GOOD) ||
              (DockingApproachExample_Ext_DW.GPS_AbsoluteTime ==
               DockingApproachExample_Ext_GOOD) ||
              (DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteTime ==
               DockingApproachExample_Ext_GOOD)) {
            /* Transition: '<S1>:338' */
            /* /RealTimeClock_callibrate() */
            DockingApproachExample_Ext_DW.is_OrbitalState2 =
              DockingApproachExampl_IN_GOOD_p;

            /* Entry 'GOOD': '<S1>:340' */
            DockingApproachExample_Ext_DW.OrbitalState_Time =
              DockingApproachExample_Ext_GOOD;
          }
        }
        break;

       case DockingApproachExampl_IN_POOR_g:
        /* During 'POOR': '<S1>:339' */
        if ((DockingApproachExample_Ext_U.GroundTrack_Time ==
             DockingApproachExample_Ext_GOOD) ||
            (DockingApproachExample_Ext_DW.GPS_AbsoluteTime ==
             DockingApproachExample_Ext_GOOD) ||
            (DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteTime ==
             DockingApproachExample_Ext_GOOD)) {
          /* Transition: '<S1>:337' */
          DockingApproachExample_Ext_DW.is_OrbitalState2 =
            DockingApproachExampl_IN_GOOD_p;

          /* Entry 'GOOD': '<S1>:340' */
          DockingApproachExample_Ext_DW.OrbitalState_Time =
            DockingApproachExample_Ext_GOOD;
        }
        break;

       default:
        DockingApproachExample_Ext_DW.is_OrbitalState2 =
          DockingAppro_IN_NO_ACTIVE_CHILD;
        break;
      }
    }
  }

  if (DockingApproachExample_Ext_DW.is_active_GPS != 0U) {
    /* During 'GPS': '<S1>:341' */
    /* 6 */
    b_previousEvent = DockingApproachExample_Ext_DW.GPS_timer + 1;
    if (b_previousEvent <= 6) {
      DockingApproachExample_Ext_DW.GPS_timer = (int8_T)b_previousEvent;
    } else {
      DockingApproachExample_Ext_DW.GPS_timer = 6;
    }

    switch (DockingApproachExample_Ext_DW.is_GPS) {
     case DockingApproachExa_IN_ACQUIRING:
      /* During 'ACQUIRING': '<S1>:350' */
      if ((DockingApproachExample_Ext_U.GPS_satelliteVisibility_status !=
           DockingApproachExample_Ext_NONE) &&
          DockingApproachExample_Ext_U.GPS_receiverAvailability_status) {
        /* Transition: '<S1>:345' */
        DockingApproachExample_Ext_DW.is_GPS = DockingApproachExample__IN_POOR;

        /* Entry 'POOR': '<S1>:351' */
        DockingApproachExample_Ext_DW.GPS_timer = 0;
        DockingApproachExample_Ext_DW.GPS_AbsolutePosition =
          DockingApproachExample_Ext_POOR;
        DockingApproachExample_Ext_DW.GPS_AbsoluteVelocity =
          DockingApproachExample_Ext_POOR;
        DockingApproachExample_Ext_DW.GPS_AbsoluteTime =
          DockingApproachExample_Ext_POOR;
      } else {
        if ((DockingApproachExample_Ext_U.GPS_satelliteVisibility_status ==
             DockingApproachExample_Ext_NONE) ||
            (!DockingApproachExample_Ext_U.GPS_receiverAvailability_status)) {
          /* Transition: '<S1>:344' */
          DockingApproachExample_Ext_DW.is_GPS = DockingApproachExa_IN_ACQUIRING;

          /* Entry 'ACQUIRING': '<S1>:350' */
          DockingApproachExample_Ext_DW.GPS_AbsolutePosition =
            DockingApproachExample_Ext_NONE;
          DockingApproachExample_Ext_DW.GPS_AbsoluteVelocity =
            DockingApproachExample_Ext_NONE;
          DockingApproachExample_Ext_DW.GPS_AbsoluteTime =
            DockingApproachExample_Ext_NONE;
        }
      }
      break;

     case DockingApproachExample__IN_GOOD:
      /* During 'GOOD': '<S1>:352' */
      if ((!((DockingApproachExample_Ext_U.GPS_satelliteVisibility_status ==
              DockingApproachExample_Ext_GOOD) &&
             DockingApproachExample_Ext_U.GPS_receiverAvailability_status)) ||
          DockingApproachExample_Ext_U.sunlight_status) {
        /* Transition: '<S1>:347' */
        DockingApproachExample_Ext_DW.is_GPS = DockingApproachExample__IN_POOR;

        /* Entry 'POOR': '<S1>:351' */
        DockingApproachExample_Ext_DW.GPS_timer = 0;
        DockingApproachExample_Ext_DW.GPS_AbsolutePosition =
          DockingApproachExample_Ext_POOR;
        DockingApproachExample_Ext_DW.GPS_AbsoluteVelocity =
          DockingApproachExample_Ext_POOR;
        DockingApproachExample_Ext_DW.GPS_AbsoluteTime =
          DockingApproachExample_Ext_POOR;
      } else {
        if ((DockingApproachExample_Ext_U.GPS_satelliteVisibility_status ==
             DockingApproachExample_Ext_GOOD) &&
            DockingApproachExample_Ext_U.GPS_receiverAvailability_status &&
            (!DockingApproachExample_Ext_U.sunlight_status)) {
          /* Transition: '<S1>:349' */
          DockingApproachExample_Ext_DW.is_GPS = DockingApproachExample__IN_GOOD;

          /* Entry 'GOOD': '<S1>:352' */
          DockingApproachExample_Ext_DW.GPS_AbsolutePosition =
            DockingApproachExample_Ext_GOOD;
          DockingApproachExample_Ext_DW.GPS_AbsoluteVelocity =
            DockingApproachExample_Ext_GOOD;
          DockingApproachExample_Ext_DW.GPS_AbsoluteTime =
            DockingApproachExample_Ext_GOOD;
        }
      }
      break;

     case DockingApproachExample__IN_POOR:
      /* During 'POOR': '<S1>:351' */
      /* 5 */
      if ((DockingApproachExample_Ext_DW.GPS_timer ==
           DockingAp_GPS_timer_upper_limit) &&
          ((DockingApproachExample_Ext_U.GPS_satelliteVisibility_status ==
            DockingApproachExample_Ext_NONE) ||
           (!DockingApproachExample_Ext_U.GPS_receiverAvailability_status))) {
        /* Transition: '<S1>:342' */
        DockingApproachExample_Ext_DW.is_GPS = DockingApproachExa_IN_ACQUIRING;

        /* Entry 'ACQUIRING': '<S1>:350' */
        DockingApproachExample_Ext_DW.GPS_AbsolutePosition =
          DockingApproachExample_Ext_NONE;
        DockingApproachExample_Ext_DW.GPS_AbsoluteVelocity =
          DockingApproachExample_Ext_NONE;
        DockingApproachExample_Ext_DW.GPS_AbsoluteTime =
          DockingApproachExample_Ext_NONE;
      } else {
        /* 5 */
        if ((DockingApproachExample_Ext_DW.GPS_timer ==
             DockingAp_GPS_timer_upper_limit) &&
            (DockingApproachExample_Ext_U.GPS_satelliteVisibility_status ==
             DockingApproachExample_Ext_GOOD) &&
            DockingApproachExample_Ext_U.GPS_receiverAvailability_status &&
            (!DockingApproachExample_Ext_U.sunlight_status)) {
          /* Transition: '<S1>:348' */
          DockingApproachExample_Ext_DW.is_GPS = DockingApproachExample__IN_GOOD;

          /* Entry 'GOOD': '<S1>:352' */
          DockingApproachExample_Ext_DW.GPS_AbsolutePosition =
            DockingApproachExample_Ext_GOOD;
          DockingApproachExample_Ext_DW.GPS_AbsoluteVelocity =
            DockingApproachExample_Ext_GOOD;
          DockingApproachExample_Ext_DW.GPS_AbsoluteTime =
            DockingApproachExample_Ext_GOOD;
        } else {
          /* 6 */
          if (((DockingApproachExample_Ext_DW.GPS_timer <
                DockingAp_GPS_timer_upper_limit) &&
               ((DockingApproachExample_Ext_U.GPS_satelliteVisibility_status ==
                 DockingApproachExample_Ext_NONE) ||
                (!DockingApproachExample_Ext_U.GPS_receiverAvailability_status)))
              || (DockingApproachExample_Ext_U.GPS_receiverAvailability_status &&
                  ((DockingApproachExample_Ext_U.GPS_satelliteVisibility_status ==
                    DockingApproachExample_Ext_POOR) ||
                   DockingApproachExample_Ext_U.sunlight_status))) {
            /* Transition: '<S1>:346' */
            DockingApproachExample_Ext_DW.is_GPS =
              DockingApproachExample__IN_POOR;

            /* Entry 'POOR': '<S1>:351' */
            DockingApproachExample_Ext_DW.GPS_timer = 0;
            DockingApproachExample_Ext_DW.GPS_AbsolutePosition =
              DockingApproachExample_Ext_POOR;
            DockingApproachExample_Ext_DW.GPS_AbsoluteVelocity =
              DockingApproachExample_Ext_POOR;
            DockingApproachExample_Ext_DW.GPS_AbsoluteTime =
              DockingApproachExample_Ext_POOR;
          }
        }
      }
      break;

     default:
      DockingApproachExample_Ext_DW.is_GPS = DockingAppro_IN_NO_ACTIVE_CHILD;
      break;
    }
  }

  if (DockingApproachExample_Ext_DW.is_active_StarPlanetTracker != 0U) {
    /* During 'StarPlanetTracker': '<S1>:353' */
    /* 6 */
    b_previousEvent = DockingApproachExample_Ext_DW.StarPlanetTracker_timer + 1;
    if (b_previousEvent <= 6) {
      DockingApproachExample_Ext_DW.StarPlanetTracker_timer = (int8_T)
        b_previousEvent;
    } else {
      DockingApproachExample_Ext_DW.StarPlanetTracker_timer = 6;
    }

    switch (DockingApproachExample_Ext_DW.is_StarPlanetTracker) {
     case DockingApproachExa_IN_ACQUIRING:
      /* During 'ACQUIRING': '<S1>:362' */
      if ((!((DockingApproachExample_Ext_U.StarPlanetTracker_planetVisibil ==
              DockingApproachExample_Ext_NONE) ||
             (DockingApproachExample_Ext_U.StarPlanetTracker_starVisibilit ==
              DockingApproachExample_Ext_NONE))) &&
          DockingApproachExample_Ext_U.opticsAvailability_status) {
        /* Transition: '<S1>:356' */
        DockingApproachExample_Ext_DW.is_StarPlanetTracker =
          DockingApproachExample__IN_POOR;

        /* Entry 'POOR': '<S1>:363' */
        DockingApproachExample_Ext_DW.StarPlanetTracker_timer = 0;
        DockingApproachExample_Ext_DW.StarPlanetTracker_AbsolutePosit =
          DockingApproachExample_Ext_POOR;
        DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteVeloc =
          DockingApproachExample_Ext_POOR;
        DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteAttit =
          DockingApproachExample_Ext_POOR;
        DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteTime =
          DockingApproachExample_Ext_POOR;
      } else {
        if ((DockingApproachExample_Ext_U.StarPlanetTracker_planetVisibil ==
             DockingApproachExample_Ext_NONE) ||
            (DockingApproachExample_Ext_U.StarPlanetTracker_starVisibilit ==
             DockingApproachExample_Ext_NONE) ||
            (!DockingApproachExample_Ext_U.opticsAvailability_status)) {
          /* Transition: '<S1>:355' */
          DockingApproachExample_Ext_DW.is_StarPlanetTracker =
            DockingApproachExa_IN_ACQUIRING;

          /* Entry 'ACQUIRING': '<S1>:362' */
          DockingApproachExample_Ext_DW.StarPlanetTracker_AbsolutePosit =
            DockingApproachExample_Ext_NONE;
          DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteVeloc =
            DockingApproachExample_Ext_NONE;
          DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteAttit =
            DockingApproachExample_Ext_NONE;
          DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteTime =
            DockingApproachExample_Ext_NONE;
        }
      }
      break;

     case DockingApproachExample__IN_GOOD:
      /* During 'GOOD': '<S1>:364' */
      if (((DockingApproachExample_Ext_U.StarPlanetTracker_planetVisibil !=
            DockingApproachExample_Ext_GOOD) &&
           (DockingApproachExample_Ext_U.StarPlanetTracker_starVisibilit !=
            DockingApproachExample_Ext_GOOD) &&
           (!DockingApproachExample_Ext_U.opticsAvailability_status)) ||
          DockingApproachExample_Ext_U.sunlight_status) {
        /* Transition: '<S1>:360' */
        DockingApproachExample_Ext_DW.is_StarPlanetTracker =
          DockingApproachExample__IN_POOR;

        /* Entry 'POOR': '<S1>:363' */
        DockingApproachExample_Ext_DW.StarPlanetTracker_timer = 0;
        DockingApproachExample_Ext_DW.StarPlanetTracker_AbsolutePosit =
          DockingApproachExample_Ext_POOR;
        DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteVeloc =
          DockingApproachExample_Ext_POOR;
        DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteAttit =
          DockingApproachExample_Ext_POOR;
        DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteTime =
          DockingApproachExample_Ext_POOR;
      } else {
        if ((DockingApproachExample_Ext_U.StarPlanetTracker_planetVisibil ==
             DockingApproachExample_Ext_GOOD) &&
            (DockingApproachExample_Ext_U.StarPlanetTracker_starVisibilit ==
             DockingApproachExample_Ext_GOOD) &&
            DockingApproachExample_Ext_U.opticsAvailability_status &&
            (!DockingApproachExample_Ext_U.sunlight_status)) {
          /* Transition: '<S1>:361' */
          DockingApproachExample_Ext_DW.is_StarPlanetTracker =
            DockingApproachExample__IN_GOOD;

          /* Entry 'GOOD': '<S1>:364' */
          DockingApproachExample_Ext_DW.StarPlanetTracker_AbsolutePosit =
            DockingApproachExample_Ext_GOOD;
          DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteVeloc =
            DockingApproachExample_Ext_GOOD;
          DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteAttit =
            DockingApproachExample_Ext_GOOD;
          DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteTime =
            DockingApproachExample_Ext_GOOD;
        }
      }
      break;

     case DockingApproachExample__IN_POOR:
      /* During 'POOR': '<S1>:363' */
      /* 6 */
      if ((DockingApproachExample_Ext_DW.StarPlanetTracker_timer ==
           StarPlanetTracker_timer_upper_l) &&
          ((DockingApproachExample_Ext_U.StarPlanetTracker_planetVisibil ==
            DockingApproachExample_Ext_NONE) ||
           (DockingApproachExample_Ext_U.StarPlanetTracker_starVisibilit ==
            DockingApproachExample_Ext_NONE) ||
           (!DockingApproachExample_Ext_U.opticsAvailability_status))) {
        /* Transition: '<S1>:357' */
        DockingApproachExample_Ext_DW.is_StarPlanetTracker =
          DockingApproachExa_IN_ACQUIRING;

        /* Entry 'ACQUIRING': '<S1>:362' */
        DockingApproachExample_Ext_DW.StarPlanetTracker_AbsolutePosit =
          DockingApproachExample_Ext_NONE;
        DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteVeloc =
          DockingApproachExample_Ext_NONE;
        DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteAttit =
          DockingApproachExample_Ext_NONE;
        DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteTime =
          DockingApproachExample_Ext_NONE;
      } else {
        /*  6 */
        if ((DockingApproachExample_Ext_DW.StarPlanetTracker_timer ==
             StarPlanetTracker_timer_upper_l) &&
            (DockingApproachExample_Ext_U.StarPlanetTracker_planetVisibil ==
             DockingApproachExample_Ext_GOOD) &&
            (DockingApproachExample_Ext_U.StarPlanetTracker_starVisibilit ==
             DockingApproachExample_Ext_GOOD) &&
            DockingApproachExample_Ext_U.opticsAvailability_status &&
            (!DockingApproachExample_Ext_U.sunlight_status)) {
          /* Transition: '<S1>:359' */
          DockingApproachExample_Ext_DW.is_StarPlanetTracker =
            DockingApproachExample__IN_GOOD;

          /* Entry 'GOOD': '<S1>:364' */
          DockingApproachExample_Ext_DW.StarPlanetTracker_AbsolutePosit =
            DockingApproachExample_Ext_GOOD;
          DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteVeloc =
            DockingApproachExample_Ext_GOOD;
          DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteAttit =
            DockingApproachExample_Ext_GOOD;
          DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteTime =
            DockingApproachExample_Ext_GOOD;
        } else {
          /* 6  */
          if (((DockingApproachExample_Ext_DW.StarPlanetTracker_timer <
                StarPlanetTracker_timer_upper_l) &&
               ((DockingApproachExample_Ext_U.StarPlanetTracker_planetVisibil ==
                 DockingApproachExample_Ext_NONE) ||
                (DockingApproachExample_Ext_U.StarPlanetTracker_starVisibilit ==
                 DockingApproachExample_Ext_NONE) ||
                (!DockingApproachExample_Ext_U.opticsAvailability_status))) ||
              (DockingApproachExample_Ext_U.opticsAvailability_status &&
               (DockingApproachExample_Ext_U.sunlight_status ||
                (DockingApproachExample_Ext_U.StarPlanetTracker_planetVisibil ==
                 DockingApproachExample_Ext_POOR) ||
                (DockingApproachExample_Ext_U.StarPlanetTracker_starVisibilit ==
                 DockingApproachExample_Ext_POOR)))) {
            /* Transition: '<S1>:358' */
            DockingApproachExample_Ext_DW.is_StarPlanetTracker =
              DockingApproachExample__IN_POOR;

            /* Entry 'POOR': '<S1>:363' */
            DockingApproachExample_Ext_DW.StarPlanetTracker_timer = 0;
            DockingApproachExample_Ext_DW.StarPlanetTracker_AbsolutePosit =
              DockingApproachExample_Ext_POOR;
            DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteVeloc =
              DockingApproachExample_Ext_POOR;
            DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteAttit =
              DockingApproachExample_Ext_POOR;
            DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteTime =
              DockingApproachExample_Ext_POOR;
          }
        }
      }
      break;

     default:
      DockingApproachExample_Ext_DW.is_StarPlanetTracker =
        DockingAppro_IN_NO_ACTIVE_CHILD;
      break;
    }
  }

  if (DockingApproachExample_Ext_DW.is_active_InertialNavigation != 0U) {
    DockingAppro_InertialNavigation();
  }
}

/* Function for Chart: '<Root>/Chart' */
static void D_exit_internal_DockingApproach(void)
{
  /* Exit Internal 'DockingApproach': '<S1>:19' */
  /* Exit Internal 'dockingSensor': '<S1>:28' */
  switch (DockingApproachExample_Ext_DW.is_dockingSensor) {
   case DockingApproachExa_IN_Acquiring:
    /* Exit 'Acquiring': '<S1>:23' */
    DockingApproachExample_Ext_DW.dockingSensor_timer = 0;
    DockingApproachExample_Ext_DW.is_dockingSensor =
      DockingAppro_IN_NO_ACTIVE_CHILD;
    break;

   case DockingApproachExample__IN_Good:
    /* Exit 'Good': '<S1>:2' */
    DockingApproachExample_Ext_DW.dockingSensor_timer = 0;
    DockingApproachExample_Ext_DW.is_dockingSensor =
      DockingAppro_IN_NO_ACTIVE_CHILD;
    break;

   default:
    DockingApproachExample_Ext_DW.is_dockingSensor =
      DockingAppro_IN_NO_ACTIVE_CHILD;
    break;
  }

  DockingApproachExample_Ext_DW.is_active_dockingSensor = 0U;

  /* Exit Internal 'DockingApproach': '<S1>:20' */
  if (DockingApproachExample_Ext_DW.is_DockingApproach ==
      DockingApproachE_IN_ReadyToDock) {
    /* Exit 'ReadyToDock': '<S1>:25' */
    DockingApproachExample_Ext_Y.DockingApproachComplete = TRUE;
    DockingApproachExample_Ext_DW.is_DockingApproach =
      DockingAppro_IN_NO_ACTIVE_CHILD;
  } else {
    DockingApproachExample_Ext_DW.is_DockingApproach =
      DockingAppro_IN_NO_ACTIVE_CHILD;
  }

  DockingApproachExample_Ext_DW.is_active_DockingApproach = 0U;
}

/* Function for Chart: '<Root>/Chart' */
static void enter_internal_OrbitalState_Act(void)
{
  /* Entry Internal 'OrbitalState_Active': '<S1>:307' */
  DockingApproachExample_Ext_DW.is_active_OrbitalState_Complex = 1U;

  /* Entry Internal 'OrbitalState_Complex': '<S1>:308' */
  DockingApproachExample_Ext_DW.is_active_OrbitalState = 1U;

  /* Entry Internal 'OrbitalState': '<S1>:309' */
  /* Transition: '<S1>:315' */
  if (DockingApproachExample_Ext_DW.is_OrbitalState !=
      DockingApproachExa_IN_Acquiring) {
    DockingApproachExample_Ext_DW.is_OrbitalState =
      DockingApproachExa_IN_Acquiring;

    /* Entry 'Acquiring': '<S1>:326' */
    DockingApproachExample_Ext_DW.OrbitalState_Position =
      DockingApproachExample_Ext_NONE;
    DockingApproachExample_Ext_DW.OrbitalState_Velocity =
      DockingApproachExample_Ext_NONE;
    DockingApproachExample_Ext_DW.OrbitalState_Attitude =
      DockingApproachExample_Ext_NONE;
  }

  DockingApproachExample_Ext_DW.is_active_OrbitalState2 = 1U;

  /* Entry Internal 'OrbitalState2': '<S1>:334' */
  /* Transition: '<S1>:335' */
  if (DockingApproachExample_Ext_DW.is_OrbitalState2 !=
      DockingApproachExampl_IN_POOR_g) {
    DockingApproachExample_Ext_DW.is_OrbitalState2 =
      DockingApproachExampl_IN_POOR_g;

    /* Entry 'POOR': '<S1>:339' */
    DockingApproachExample_Ext_DW.OrbitalState_Time =
      DockingApproachExample_Ext_POOR;
  }

  DockingApproachExample_Ext_DW.is_active_GPS = 1U;

  /* Entry Internal 'GPS': '<S1>:341' */
  /* Transition: '<S1>:343' */
  if (DockingApproachExample_Ext_DW.is_GPS != DockingApproachExa_IN_ACQUIRING) {
    DockingApproachExample_Ext_DW.is_GPS = DockingApproachExa_IN_ACQUIRING;

    /* Entry 'ACQUIRING': '<S1>:350' */
    DockingApproachExample_Ext_DW.GPS_AbsolutePosition =
      DockingApproachExample_Ext_NONE;
    DockingApproachExample_Ext_DW.GPS_AbsoluteVelocity =
      DockingApproachExample_Ext_NONE;
    DockingApproachExample_Ext_DW.GPS_AbsoluteTime =
      DockingApproachExample_Ext_NONE;
  }

  DockingApproachExample_Ext_DW.is_active_StarPlanetTracker = 1U;

  /* Entry Internal 'StarPlanetTracker': '<S1>:353' */
  /* Transition: '<S1>:354' */
  if (DockingApproachExample_Ext_DW.is_StarPlanetTracker !=
      DockingApproachExa_IN_ACQUIRING) {
    DockingApproachExample_Ext_DW.is_StarPlanetTracker =
      DockingApproachExa_IN_ACQUIRING;

    /* Entry 'ACQUIRING': '<S1>:362' */
    DockingApproachExample_Ext_DW.StarPlanetTracker_AbsolutePosit =
      DockingApproachExample_Ext_NONE;
    DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteVeloc =
      DockingApproachExample_Ext_NONE;
    DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteAttit =
      DockingApproachExample_Ext_NONE;
    DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteTime =
      DockingApproachExample_Ext_NONE;
  }

  DockingApproachExample_Ext_DW.is_active_InertialNavigation = 1U;

  /* Entry 'InertialNavigation': '<S1>:366' */
  DockingApproachExample_Ext_DW.VALID = FALSE;

  /* Entry Internal 'InertialNavigation': '<S1>:366' */
  /* Transition: '<S1>:368' */
  if (DockingApproachExample_Ext_DW.is_InertialNavigation !=
      DockingApproachExa_IN_ACQUIRING) {
    DockingApproachExample_Ext_DW.is_InertialNavigation =
      DockingApproachExa_IN_ACQUIRING;

    /* Entry 'ACQUIRING': '<S1>:376' */
    DockingApproachExample_Ext_DW.InertialNavigation_AbsolutePosi =
      DockingApproachExample_Ext_NONE;
    DockingApproachExample_Ext_DW.InertialNavigation_AbsoluteVelo =
      DockingApproachExample_Ext_NONE;
    DockingApproachExample_Ext_DW.InertialNavigation_AbsoluteAtti =
      DockingApproachExample_Ext_NONE;
  }
}

/* Function for Chart: '<Root>/Chart' */
static void DockingApproach_DockingApproach(void)
{
  int32_T u;

  /* During 'DockingApproach': '<S1>:19' */
  if (DockingApproachExample_Ext_DW.is_active_DockingApproach != 0U) {
    /* During 'DockingApproach': '<S1>:20' */
    /* 9 */
    u = DockingApproachExample_Ext_DW.DockingApproach_timer + 1;
    if (u <= 9) {
      DockingApproachExample_Ext_DW.DockingApproach_timer = (int8_T)u;
    } else {
      DockingApproachExample_Ext_DW.DockingApproach_timer = 9;
    }

    switch (DockingApproachExample_Ext_DW.is_DockingApproach) {
     case Doc_IN_CheckTargetRelativeState:
      /* During 'CheckTargetRelativeState': '<S1>:24' */
      if ((DockingApproachExample_Ext_DW.dockingSensor_RelativePosition ==
           DockingApproachExample_Ext_GOOD) &&
          ((DockingApproachExample_Ext_DW.dockingSensor_RelativeVelocity ==
            DockingApproachExample_Ext_GOOD) &&
           (DockingApproachExample_Ext_DW.dockingSensor_RelativeAttitude ==
            DockingApproachExample_Ext_GOOD)) &&
          (DockingApproachExample_Ext_DW.dockingSensor_targetState ==
           DockingApproachExample_Ext_GOOD)) {
        /* Transition: '<S1>:98' */
        /*  MissionState_status == GOOD  */
        DockingApproachExample_Ext_DW.is_DockingApproach =
          DockingApproachE_IN_ReadyToDock;
      } else if ((DockingApproachExample_Ext_DW.dockingSensor_RelativePosition ==
                  DockingApproachExample_Ext_POOR) &&
                 (DockingApproachExample_Ext_DW.dockingSensor_RelativeVelocity ==
                  DockingApproachExample_Ext_POOR) &&
                 (DockingApproachExample_Ext_DW.dockingSensor_RelativeAttitude ==
                  DockingApproachExample_Ext_POOR) &&
                 (DockingApproachExample_Ext_DW.dockingSensor_targetState ==
                  DockingApproachExample_Ext_POOR)) {
        /* Transition: '<S1>:102' */
        /*  MissionState_status == POOR  */
        DockingApproachExample_Ext_DW.is_DockingApproach =
          DockingApproac_IN_ComputeThrust;
      } else {
        /* 9 */
        if (DockingApproachExample_Ext_DW.DockingApproach_timer ==
            DockingApproach_timer_upper_lim) {
          /* Transition: '<S1>:187' */
          DockingApproachExample_Ext_DW.is_DockingApproach =
            Dockin_IN_DockingApproachFailed;
        } else if ((DockingApproachExample_Ext_DW.dockingSensor_RelativePosition
                    == DockingApproachExample_Ext_NONE) ||
                   (DockingApproachExample_Ext_DW.dockingSensor_RelativeVelocity
                    == DockingApproachExample_Ext_NONE) ||
                   (DockingApproachExample_Ext_DW.dockingSensor_RelativeAttitude
                    == DockingApproachExample_Ext_NONE)) {
          /* Transition: '<S1>:101' */
          DockingApproachExample_Ext_DW.is_DockingApproach =
            Dockin_IN_DockingApproachFailed;
        } else {
          if (DockingApproachExample_Ext_DW.dockingSensor_targetState !=
              DockingApproachExample_Ext_GOOD) {
            /* Transition: '<S1>:99' */
            DockingApproachExample_Ext_DW.is_DockingApproach =
              Dockin_IN_DockingApproachFailed;
          }
        }
      }
      break;

     case DockingApproac_IN_ComputeThrust:
      /* During 'ComputeThrust': '<S1>:26' */
      if ((DockingApproachExample_Ext_DW.thrust_status ==
           DockingApproachExample_Ex_EXIST) &&
          (DockingApproachExample_Ext_DW.fuel_status ==
           DockingApproachExample_Ext_GOOD)) {
        /* Transition: '<S1>:100' */
        DockingApproachExample_Ext_DW.is_DockingApproach =
          Doc_IN_CheckTargetRelativeState;

        /* Entry 'CheckTargetRelativeState': '<S1>:24' */
        /*  missionState.compute (...)  */
      } else {
        if ((!((DockingApproachExample_Ext_DW.thrust_status ==
                DockingApproachExample_Ex_EXIST) &&
               (DockingApproachExample_Ext_DW.fuel_status ==
                DockingApproachExample_Ext_GOOD))) ||
            (DockingApproachExample_Ext_DW.DockingApproach_timer ==
             DockingApproach_timer_upper_lim)) {
          /* Transition: '<S1>:104' */
          DockingApproachExample_Ext_DW.is_DockingApproach =
            Dockin_IN_DockingApproachFailed;
        }
      }
      break;

     case Dockin_IN_DockingApproachFailed:
      /* During 'DockingApproachFailed': '<S1>:27' */
      /* Transition: '<S1>:177' */
      /* DockingApproachFailed */
      D_exit_internal_DockingApproach();
      if (DockingApproachExample_Ext_DW.is_MissionPhaseStates ==
          DockingAppro_IN_DockingApproach) {
        /* Exit 'DockingApproach': '<S1>:19' */
        DockingApproachExample_Ext_Y.DockingApproach = FALSE;
      }

      DockingApproachExample_Ext_DW.is_MissionPhaseStates =
        DockingAppro_IN_CaptureApproach;
      DockingApproachExample_Ext_DW.is_active_CaptureApproach = 1U;
      DockingApproachExample_Ext_DW.is_CaptureApproach =
        DockingApp_IN_CheckOrbitalState;
      DockingApproachExample_Ext_DW.is_active_OrbitalState_Active = 1U;
      enter_internal_OrbitalState_Act();
      break;

     case DockingApproachE_IN_ReadyToDock:
      /* During 'ReadyToDock': '<S1>:25' */
      /* Transition: '<S1>:184' */
      /* ReadyToDock */
      D_exit_internal_DockingApproach();
      if (DockingApproachExample_Ext_DW.is_MissionPhaseStates ==
          DockingAppro_IN_DockingApproach) {
        /* Exit 'DockingApproach': '<S1>:19' */
        DockingApproachExample_Ext_Y.DockingApproach = FALSE;
      }

      DockingApproachExample_Ext_DW.is_MissionPhaseStates =
        DockingApproach_IN_LatchCapture;

      /* Entry Internal 'LatchCapture': '<S1>:385' */
      if (DockingApproachExample_Ext_DW.is_active_LatchCaptureCheck != 1U) {
        DockingApproachExample_Ext_DW.is_active_LatchCaptureCheck = 1U;

        /* Entry 'LatchCaptureCheck': '<S1>:390' */
        DockingApproachExample_Ext_Y.AttemptingToDock = TRUE;
      }

      /* Entry Internal 'LatchCaptureCheck': '<S1>:390' */
      /* Transition: '<S1>:392' */
      if (DockingApproachExample_Ext_DW.is_LatchCaptureCheck !=
          DockingApproa_IN_CheckLatchOpen) {
        DockingApproachExample_Ext_DW.is_LatchCaptureCheck =
          DockingApproa_IN_CheckLatchOpen;

        /* Entry 'CheckLatchOpen': '<S1>:399' */
        DockingApproachExample_Ext_DW.LatchCapture_timer = 0;
      }

      DockingApproachExample_Ext_DW.is_active_latch = 1U;

      /* Entry Internal 'latch': '<S1>:403' */
      /* Transition: '<S1>:405' */
      if (DockingApproachExample_Ext_DW.is_latch !=
          DockingApproachExamp_IN_Opening) {
        DockingApproachExample_Ext_DW.is_latch = DockingApproachExamp_IN_Opening;

        /* Entry 'Opening': '<S1>:415' */
        DockingApproachExample_Ext_DW.latch_status =
          DockingApproachEx_INDETERMINATE;
      }
      break;

     case DockingApproac_IN_StartApproach:
      /* During 'StartApproach': '<S1>:22' */
      /* 9 */
      if ((DockingApproachExample_Ext_DW.dockingSensor_RelativePosition !=
           DockingApproachExample_Ext_NONE) &&
          (DockingApproachExample_Ext_DW.dockingSensor_RelativeVelocity !=
           DockingApproachExample_Ext_NONE) &&
          (DockingApproachExample_Ext_DW.dockingSensor_RelativeAttitude !=
           DockingApproachExample_Ext_NONE) &&
          (DockingApproachExample_Ext_DW.DockingApproach_timer <
           DockingApproach_timer_upper_lim)) {
        /* Transition: '<S1>:94' */
        DockingApproachExample_Ext_DW.is_DockingApproach =
          Doc_IN_CheckTargetRelativeState;

        /* Entry 'CheckTargetRelativeState': '<S1>:24' */
        /*  missionState.compute (...)  */
      } else {
        /* 9 */
        if (DockingApproachExample_Ext_DW.DockingApproach_timer ==
            DockingApproach_timer_upper_lim) {
          /* Transition: '<S1>:96' */
          DockingApproachExample_Ext_DW.is_DockingApproach =
            Dockin_IN_DockingApproachFailed;
        }
      }
      break;

     default:
      DockingApproachExample_Ext_DW.is_DockingApproach =
        DockingAppro_IN_NO_ACTIVE_CHILD;
      break;
    }
  }

  if (!((DockingApproachExample_Ext_DW.is_MissionPhaseStates !=
         DockingAppro_IN_DockingApproach) ||
        (DockingApproachExample_Ext_DW.is_active_dockingSensor == 0U))) {
    /* During 'dockingSensor': '<S1>:28' */
    /* 6 */
    u = DockingApproachExample_Ext_DW.dockingSensor_timer + 1;
    if (u <= 6) {
      DockingApproachExample_Ext_DW.dockingSensor_timer = (int8_T)u;
    } else {
      DockingApproachExample_Ext_DW.dockingSensor_timer = 6;
    }

    switch (DockingApproachExample_Ext_DW.is_dockingSensor) {
     case DockingApproachExa_IN_Acquiring:
      /* During 'Acquiring': '<S1>:23' */
      if ((DockingApproachExample_Ext_U.dockVisibility_status !=
           DockingApproachExample_Ext_NONE) &&
          DockingApproachExample_Ext_U.opticsAvailability_status) {
        /* Transition: '<S1>:110' */
        if (DockingApproachExample_Ext_DW.is_dockingSensor ==
            DockingApproachExa_IN_Acquiring) {
          /* Exit 'Acquiring': '<S1>:23' */
          DockingApproachExample_Ext_DW.dockingSensor_timer = 0;
          DockingApproachExample_Ext_DW.is_dockingSensor =
            DockingAppro_IN_NO_ACTIVE_CHILD;
        }

        if (DockingApproachExample_Ext_DW.is_dockingSensor !=
            DockingApproachExample__IN_Poor) {
          DockingApproachExample_Ext_DW.is_dockingSensor =
            DockingApproachExample__IN_Poor;

          /* Entry 'Poor': '<S1>:21' */
          DockingApproachExample_Ext_DW.dockingSensor_RelativePosition =
            DockingApproachExample_Ext_POOR;
          DockingApproachExample_Ext_DW.dockingSensor_RelativeVelocity =
            DockingApproachExample_Ext_POOR;
          DockingApproachExample_Ext_DW.dockingSensor_RelativeAttitude =
            DockingApproachExample_Ext_POOR;
          DockingApproachExample_Ext_DW.dockingSensor_targetState =
            DockingApproachExample_Ext_POOR;
        }
      } else {
        if ((DockingApproachExample_Ext_U.dockVisibility_status ==
             DockingApproachExample_Ext_NONE) ||
            (!DockingApproachExample_Ext_U.opticsAvailability_status)) {
          /* Transition: '<S1>:109' */
          if (DockingApproachExample_Ext_DW.is_dockingSensor ==
              DockingApproachExa_IN_Acquiring) {
            /* Exit 'Acquiring': '<S1>:23' */
            DockingApproachExample_Ext_DW.dockingSensor_timer = 0;
            DockingApproachExample_Ext_DW.is_dockingSensor =
              DockingAppro_IN_NO_ACTIVE_CHILD;
          }

          if (DockingApproachExample_Ext_DW.is_dockingSensor !=
              DockingApproachExa_IN_Acquiring) {
            DockingApproachExample_Ext_DW.is_dockingSensor =
              DockingApproachExa_IN_Acquiring;

            /* Entry 'Acquiring': '<S1>:23' */
            DockingApproachExample_Ext_DW.dockingSensor_RelativePosition =
              DockingApproachExample_Ext_NONE;
            DockingApproachExample_Ext_DW.dockingSensor_RelativeVelocity =
              DockingApproachExample_Ext_NONE;
            DockingApproachExample_Ext_DW.dockingSensor_RelativeAttitude =
              DockingApproachExample_Ext_NONE;
            DockingApproachExample_Ext_DW.dockingSensor_targetState =
              DockingApproachExample_Ext_NONE;
          }
        }
      }
      break;

     case DockingApproachExample__IN_Good:
      /* During 'Good': '<S1>:2' */
      if (((DockingApproachExample_Ext_U.dockVisibility_status !=
            DockingApproachExample_Ext_GOOD) &&
           (!DockingApproachExample_Ext_U.opticsAvailability_status)) ||
          DockingApproachExample_Ext_U.sunlight_status) {
        /* Transition: '<S1>:112' */
        if (DockingApproachExample_Ext_DW.is_dockingSensor ==
            DockingApproachExample__IN_Good) {
          /* Exit 'Good': '<S1>:2' */
          DockingApproachExample_Ext_DW.dockingSensor_timer = 0;
          DockingApproachExample_Ext_DW.is_dockingSensor =
            DockingAppro_IN_NO_ACTIVE_CHILD;
        }

        if (DockingApproachExample_Ext_DW.is_dockingSensor !=
            DockingApproachExample__IN_Poor) {
          DockingApproachExample_Ext_DW.is_dockingSensor =
            DockingApproachExample__IN_Poor;

          /* Entry 'Poor': '<S1>:21' */
          DockingApproachExample_Ext_DW.dockingSensor_RelativePosition =
            DockingApproachExample_Ext_POOR;
          DockingApproachExample_Ext_DW.dockingSensor_RelativeVelocity =
            DockingApproachExample_Ext_POOR;
          DockingApproachExample_Ext_DW.dockingSensor_RelativeAttitude =
            DockingApproachExample_Ext_POOR;
          DockingApproachExample_Ext_DW.dockingSensor_targetState =
            DockingApproachExample_Ext_POOR;
        }
      } else {
        if ((DockingApproachExample_Ext_U.dockVisibility_status ==
             DockingApproachExample_Ext_GOOD) &&
            DockingApproachExample_Ext_U.opticsAvailability_status &&
            (!DockingApproachExample_Ext_U.sunlight_status)) {
          /* Transition: '<S1>:114' */
          if (DockingApproachExample_Ext_DW.is_dockingSensor ==
              DockingApproachExample__IN_Good) {
            /* Exit 'Good': '<S1>:2' */
            DockingApproachExample_Ext_DW.dockingSensor_timer = 0;
            DockingApproachExample_Ext_DW.is_dockingSensor =
              DockingAppro_IN_NO_ACTIVE_CHILD;
          }

          if (DockingApproachExample_Ext_DW.is_dockingSensor !=
              DockingApproachExample__IN_Good) {
            DockingApproachExample_Ext_DW.is_dockingSensor =
              DockingApproachExample__IN_Good;

            /* Entry 'Good': '<S1>:2' */
            DockingApproachExample_Ext_DW.dockingSensor_RelativePosition =
              DockingApproachExample_Ext_GOOD;
            DockingApproachExample_Ext_DW.dockingSensor_RelativeVelocity =
              DockingApproachExample_Ext_GOOD;
            DockingApproachExample_Ext_DW.dockingSensor_RelativeAttitude =
              DockingApproachExample_Ext_GOOD;
            DockingApproachExample_Ext_DW.dockingSensor_targetState =
              DockingApproachExample_Ext_GOOD;
          }
        }
      }
      break;

     case DockingApproachExample__IN_Poor:
      /* During 'Poor': '<S1>:21' */
      /* 6 */
      if ((DockingApproachExample_Ext_DW.dockingSensor_timer ==
           dockingSensor_timer_upper_limit) &&
          ((DockingApproachExample_Ext_U.dockVisibility_status ==
            DockingApproachExample_Ext_NONE) ||
           (!DockingApproachExample_Ext_U.opticsAvailability_status))) {
        /* Transition: '<S1>:108' */
        DockingApproachExample_Ext_DW.is_dockingSensor =
          DockingApproachExa_IN_Acquiring;

        /* Entry 'Acquiring': '<S1>:23' */
        DockingApproachExample_Ext_DW.dockingSensor_RelativePosition =
          DockingApproachExample_Ext_NONE;
        DockingApproachExample_Ext_DW.dockingSensor_RelativeVelocity =
          DockingApproachExample_Ext_NONE;
        DockingApproachExample_Ext_DW.dockingSensor_RelativeAttitude =
          DockingApproachExample_Ext_NONE;
        DockingApproachExample_Ext_DW.dockingSensor_targetState =
          DockingApproachExample_Ext_NONE;
      } else {
        /*  or ==6?  */
        if ((DockingApproachExample_Ext_DW.dockingSensor_timer <
             dockingSensor_timer_upper_limit) &&
            (DockingApproachExample_Ext_U.dockVisibility_status ==
             DockingApproachExample_Ext_GOOD) &&
            DockingApproachExample_Ext_U.opticsAvailability_status &&
            (!DockingApproachExample_Ext_U.sunlight_status)) {
          /* Transition: '<S1>:113' */
          DockingApproachExample_Ext_DW.is_dockingSensor =
            DockingApproachExample__IN_Good;

          /* Entry 'Good': '<S1>:2' */
          DockingApproachExample_Ext_DW.dockingSensor_RelativePosition =
            DockingApproachExample_Ext_GOOD;
          DockingApproachExample_Ext_DW.dockingSensor_RelativeVelocity =
            DockingApproachExample_Ext_GOOD;
          DockingApproachExample_Ext_DW.dockingSensor_RelativeAttitude =
            DockingApproachExample_Ext_GOOD;
          DockingApproachExample_Ext_DW.dockingSensor_targetState =
            DockingApproachExample_Ext_GOOD;
        } else {
          /* 6 */
          if (((DockingApproachExample_Ext_DW.dockingSensor_timer <
                dockingSensor_timer_upper_limit) &&
               ((DockingApproachExample_Ext_U.dockVisibility_status ==
                 DockingApproachExample_Ext_NONE) ||
                (!DockingApproachExample_Ext_U.opticsAvailability_status))) ||
              (DockingApproachExample_Ext_U.opticsAvailability_status &&
               ((DockingApproachExample_Ext_U.dockVisibility_status ==
                 DockingApproachExample_Ext_POOR) ||
                DockingApproachExample_Ext_U.sunlight_status))) {
            /* Transition: '<S1>:111' */
            DockingApproachExample_Ext_DW.is_dockingSensor =
              DockingApproachExample__IN_Poor;

            /* Entry 'Poor': '<S1>:21' */
            DockingApproachExample_Ext_DW.dockingSensor_RelativePosition =
              DockingApproachExample_Ext_POOR;
            DockingApproachExample_Ext_DW.dockingSensor_RelativeVelocity =
              DockingApproachExample_Ext_POOR;
            DockingApproachExample_Ext_DW.dockingSensor_RelativeAttitude =
              DockingApproachExample_Ext_POOR;
            DockingApproachExample_Ext_DW.dockingSensor_targetState =
              DockingApproachExample_Ext_POOR;
          }
        }
      }
      break;

     default:
      DockingApproachExample_Ext_DW.is_dockingSensor =
        DockingAppro_IN_NO_ACTIVE_CHILD;
      break;
    }
  }
}

/* Function for Chart: '<Root>/Chart' */
static void DockingAppro_MissionPhaseStates(void)
{
  int32_T u;

  /* During 'MissionPhaseStates': '<S1>:44' */
  switch (DockingApproachExample_Ext_DW.is_MissionPhaseStates) {
   case DockingApproac_IN_ApproachOrbit:
    /* During 'ApproachOrbit': '<S1>:66' */
    if (DockingApproachExample_Ext_U.StageTransition == 2) {
      /* Transition: '<S1>:176' */
      DockingApproachExample_Ext_Y.ApproachOrbitComplete = TRUE;

      /* isInSameOrbit */
      DockingApproachExample_Ext_DW.is_MissionPhaseStates =
        DockingA_IN_ProximityOperations;
    }
    break;

   case DockingAppro_IN_CaptureApproach:
    /* During 'CaptureApproach': '<S1>:283' */
    if (DockingApproachExample_Ext_DW.is_active_CaptureApproach != 0U) {
      /* During 'CaptureApproach': '<S1>:287' */
      u = DockingApproachExample_Ext_DW.CaptureApproach_timer + 1;
      if (u <= 11) {
        DockingApproachExample_Ext_DW.CaptureApproach_timer = (int8_T)u;
      } else {
        DockingApproachExample_Ext_DW.CaptureApproach_timer = 11;
      }

      switch (DockingApproachExample_Ext_DW.is_CaptureApproach) {
       case Dockin_IN_CaptureApproachFailed:
        /* During 'CaptureApproachFailed': '<S1>:305' */
        /* Transition: '<S1>:289' */
        /* CaptureApproachFailed */
        D_exit_internal_CaptureApproach();
        DockingApproachExample_Ext_DW.is_MissionPhaseStates =
          D_IN_CollisionAvoidanceManuever;
        break;

       case DockingApp_IN_CheckOrbitalState:
        /* During 'CheckOrbitalState': '<S1>:302' */
        if ((DockingApproachExample_Ext_DW.OrbitalState_Position ==
             DockingApproachExample_Ext_GOOD) &&
            (DockingApproachExample_Ext_DW.OrbitalState_Velocity ==
             DockingApproachExample_Ext_GOOD) &&
            (DockingApproachExample_Ext_DW.OrbitalState_Attitude !=
             DockingApproachExample_Ext_NONE) &&
            (DockingApproachExample_Ext_DW.OrbitalState_Time ==
             DockingApproachExample_Ext_GOOD)) {
          /* Transition: '<S1>:294' */
          DockingApproachExample_Ext_DW.is_CaptureApproach =
            D_IN_OrientedForDockingApproach;
        } else if ((DockingApproachExample_Ext_DW.OrbitalState_Position ==
                    DockingApproachExample_Ext_POOR) &&
                   (DockingApproachExample_Ext_DW.OrbitalState_Velocity ==
                    DockingApproachExample_Ext_POOR) &&
                   (DockingApproachExample_Ext_DW.OrbitalState_Attitude ==
                    DockingApproachExample_Ext_NONE) &&
                   (DockingApproachExample_Ext_DW.OrbitalState_Time ==
                    DockingApproachExample_Ext_POOR)) {
          /* Transition: '<S1>:296' */
          DockingApproachExample_Ext_DW.is_CaptureApproach =
            DockingAppro_IN_ComputeThrust_d;

          /* Entry 'ComputeThrust': '<S1>:303' */
          /* thrust.compute(CaptureMissionState) */
        } else {
          if ((DockingApproachExample_Ext_DW.OrbitalState_Position ==
               DockingApproachExample_Ext_NONE) ||
              (DockingApproachExample_Ext_DW.OrbitalState_Velocity ==
               DockingApproachExample_Ext_NONE) ||
              (DockingApproachExample_Ext_DW.OrbitalState_Attitude ==
               DockingApproachExample_Ext_NONE) ||
              (DockingApproachExample_Ext_DW.OrbitalState_Time ==
               DockingApproachExample_Ext_NONE) ||
              (DockingApproachExample_Ext_DW.CaptureApproach_timer ==
               CaptureApproach_timer_upper_lim)) {
            /* Transition: '<S1>:297' */
            DockingApproachExample_Ext_DW.is_CaptureApproach =
              Dockin_IN_CaptureApproachFailed;

            /* Entry 'CaptureApproachFailed': '<S1>:305' */
            DockingApproachExample_Ext_Y.CaptureApproachFailed = TRUE;
          }
        }
        break;

       case DockingAppro_IN_ComputeThrust_d:
        /* During 'ComputeThrust': '<S1>:303' */
        if ((DockingApproachExample_Ext_DW.thrust_status ==
             DockingApproachExample_Ex_EXIST) &&
            (DockingApproachExample_Ext_DW.fuel_status ==
             DockingApproachExample_Ext_GOOD)) {
          /* Transition: '<S1>:295' */
          DockingApproachExample_Ext_DW.is_CaptureApproach =
            DockingApp_IN_CheckOrbitalState;
        } else {
          if ((!((DockingApproachExample_Ext_DW.thrust_status ==
                  DockingApproachExample_Ex_EXIST) &&
                 (DockingApproachExample_Ext_DW.fuel_status ==
                  DockingApproachExample_Ext_GOOD))) ||
              (DockingApproachExample_Ext_DW.CaptureApproach_timer ==
               CaptureApproach_timer_upper_lim)) {
            /* Transition: '<S1>:298' */
            DockingApproachExample_Ext_DW.is_CaptureApproach =
              Dockin_IN_CaptureApproachFailed;

            /* Entry 'CaptureApproachFailed': '<S1>:305' */
            DockingApproachExample_Ext_Y.CaptureApproachFailed = TRUE;
          }
        }
        break;

       case D_IN_OrientedForDockingApproach:
        /* During 'OrientedForDockingApproach': '<S1>:304' */
        /* Transition: '<S1>:300' */
        /* Oriented */
        D_exit_internal_CaptureApproach();
        DockingApproachExample_Ext_DW.is_MissionPhaseStates =
          DockingAppro_IN_DockingApproach;

        /* Entry 'DockingApproach': '<S1>:19' */
        DockingApproachExample_Ext_Y.DockingApproach = TRUE;
        DockingApproachExample_Ext_Y.DockingApproachComplete = FALSE;

        /* Entry Internal 'DockingApproach': '<S1>:19' */
        DockingApproachExample_Ext_DW.is_active_DockingApproach = 1U;

        /* Entry Internal 'DockingApproach': '<S1>:20' */
        /* Transition: '<S1>:95' */
        if (DockingApproachExample_Ext_DW.is_DockingApproach !=
            DockingApproac_IN_StartApproach) {
          DockingApproachExample_Ext_DW.is_DockingApproach =
            DockingApproac_IN_StartApproach;

          /* Entry 'StartApproach': '<S1>:22' */
          DockingApproachExample_Ext_DW.DockingApproach_timer = 0;
        }

        DockingApproachExample_Ext_DW.is_active_dockingSensor = 1U;

        /* Entry 'dockingSensor': '<S1>:28' */
        /* Entry Internal 'dockingSensor': '<S1>:28' */
        /* Transition: '<S1>:107' */
        if (DockingApproachExample_Ext_DW.is_dockingSensor !=
            DockingApproachExa_IN_Acquiring) {
          DockingApproachExample_Ext_DW.is_dockingSensor =
            DockingApproachExa_IN_Acquiring;

          /* Entry 'Acquiring': '<S1>:23' */
          DockingApproachExample_Ext_DW.dockingSensor_RelativePosition =
            DockingApproachExample_Ext_NONE;
          DockingApproachExample_Ext_DW.dockingSensor_RelativeVelocity =
            DockingApproachExample_Ext_NONE;
          DockingApproachExample_Ext_DW.dockingSensor_RelativeAttitude =
            DockingApproachExample_Ext_NONE;
          DockingApproachExample_Ext_DW.dockingSensor_targetState =
            DockingApproachExample_Ext_NONE;
        }
        break;

       case DockingApproac_IN_StartApproach:
        /* During 'StartApproach': '<S1>:301' */
        if ((DockingApproachExample_Ext_DW.OrbitalState_Position !=
             DockingApproachExample_Ext_NONE) &&
            (DockingApproachExample_Ext_DW.OrbitalState_Velocity !=
             DockingApproachExample_Ext_NONE) &&
            (DockingApproachExample_Ext_DW.OrbitalState_Attitude !=
             DockingApproachExample_Ext_NONE) &&
            (DockingApproachExample_Ext_DW.OrbitalState_Time !=
             DockingApproachExample_Ext_NONE) &&
            (DockingApproachExample_Ext_DW.CaptureApproach_timer <
             CaptureApproach_timer_upper_lim)) {
          /* Transition: '<S1>:291' */
          DockingApproachExample_Ext_DW.is_CaptureApproach =
            DockingApp_IN_CheckOrbitalState;
        } else {
          if (DockingApproachExample_Ext_DW.CaptureApproach_timer ==
              CaptureApproach_timer_upper_lim) {
            /* Transition: '<S1>:292' */
            DockingApproachExample_Ext_DW.is_CaptureApproach =
              Dockin_IN_CaptureApproachFailed;

            /* Entry 'CaptureApproachFailed': '<S1>:305' */
            DockingApproachExample_Ext_Y.CaptureApproachFailed = TRUE;
          }
        }
        break;

       default:
        DockingApproachExample_Ext_DW.is_CaptureApproach =
          DockingAppro_IN_NO_ACTIVE_CHILD;
        break;
      }
    }

    if (!((DockingApproachExample_Ext_DW.is_MissionPhaseStates !=
           DockingAppro_IN_CaptureApproach) ||
          (DockingApproachExample_Ext_DW.is_active_OrbitalState_Active == 0U)))
    {
      DockingAppr_OrbitalState_Active();
    }
    break;

   case D_IN_CollisionAvoidanceManuever:
    /* During 'CollisionAvoidanceManuever': '<S1>:65' */
    if (DockingApproachExample_Ext_U.StageTransition == 8) {
      /* Transition: '<S1>:173' */
      /* FailedApproach */
      if (DockingApproachExample_Ext_DW.is_MissionPhaseStates ==
          D_IN_CollisionAvoidanceManuever) {
        /* Exit 'CollisionAvoidanceManuever': '<S1>:65' */
        DockingApproachExample_Ext_Y.ApproachOrbitComplete = FALSE;
        DockingApproachExample_Ext_Y.ProximityOperationsComplete = FALSE;
        DockingApproachExample_Ext_Y.FarApproachComplete = FALSE;
        DockingApproachExample_Ext_Y.CaptureApproachComplete = FALSE;
        DockingApproachExample_Ext_DW.is_MissionPhaseStates =
          DockingAppro_IN_NO_ACTIVE_CHILD;
      }

      if (DockingApproachExample_Ext_DW.is_MissionPhaseStates !=
          DockingApproa_IN_FailedApproach) {
        DockingApproachExample_Ext_DW.is_MissionPhaseStates =
          DockingApproa_IN_FailedApproach;

        /* Entry 'FailedApproach': '<S1>:38' */
        DockingApproachExample_Ext_Y.FailedApproach = TRUE;
      }
    } else {
      if (DockingApproachExample_Ext_U.StageTransition == 6) {
        /* Transition: '<S1>:93' */
        /* isSafeToApproach */
        if (DockingApproachExample_Ext_DW.is_MissionPhaseStates ==
            D_IN_CollisionAvoidanceManuever) {
          /* Exit 'CollisionAvoidanceManuever': '<S1>:65' */
          DockingApproachExample_Ext_Y.ApproachOrbitComplete = FALSE;
          DockingApproachExample_Ext_Y.ProximityOperationsComplete = FALSE;
          DockingApproachExample_Ext_Y.FarApproachComplete = FALSE;
          DockingApproachExample_Ext_Y.CaptureApproachComplete = FALSE;
        }

        DockingApproachExample_Ext_DW.is_MissionPhaseStates =
          DockingApproac_IN_ApproachOrbit;
      }
    }
    break;

   case DockingApproachExa_IN_Disengage:
    /* During 'Disengage': '<S1>:43' */
    if (DockingApproachExample_Ext_U.StageTransition == 7) {
      /* Transition: '<S1>:136' */
      /* isDisengaged */
      DockingApproachExample_Ext_DW.is_MissionPhaseStates =
        D_IN_CollisionAvoidanceManuever;
    }
    break;

   case DockingAppro_IN_DockingApproach:
    DockingApproach_DockingApproach();
    break;

   case DockingApproa_IN_FailedApproach:
    /* During 'FailedApproach': '<S1>:38' */
    break;

   case DockingApproachE_IN_FarApproach:
    /* During 'FarApproach': '<S1>:62' */
    if (DockingApproachExample_Ext_U.StageTransition == 5) {
      /* Transition: '<S1>:174' */
      /* FailedFarApproach */
      DockingApproachExample_Ext_DW.is_MissionPhaseStates =
        D_IN_CollisionAvoidanceManuever;
    } else {
      if (DockingApproachExample_Ext_U.StageTransition == 4) {
        /* Transition: '<S1>:384' */
        DockingApproachExample_Ext_Y.FarApproachComplete = TRUE;

        /* InProximity */
        DockingApproachExample_Ext_DW.is_MissionPhaseStates =
          DockingAppro_IN_CaptureApproach;

        /* Entry Internal 'CaptureApproach': '<S1>:283' */
        DockingApproachExample_Ext_DW.is_active_CaptureApproach = 1U;

        /* Entry Internal 'CaptureApproach': '<S1>:287' */
        /* Transition: '<S1>:290' */
        if (DockingApproachExample_Ext_DW.is_CaptureApproach !=
            DockingApproac_IN_StartApproach) {
          DockingApproachExample_Ext_DW.is_CaptureApproach =
            DockingApproac_IN_StartApproach;

          /* Entry 'StartApproach': '<S1>:301' */
          DockingApproachExample_Ext_DW.CaptureApproach_timer = 0;
          DockingApproachExample_Ext_Y.CaptureApproachFailed = FALSE;
        }

        DockingApproachExample_Ext_DW.is_active_OrbitalState_Active = 1U;
        enter_internal_OrbitalState_Act();
      }
    }
    break;

   case DockingApproach_IN_JointMission:
    /* During 'JointMission': '<S1>:63' */
    break;

   case DockingApproa_IN_JointStabilize:
    /* During 'JointStabilize': '<S1>:42' */
    if (DockingApproachExample_Ext_U.StageTransition == 9) {
      /* Transition: '<S1>:135' */
      /* LatchLost */
      DockingApproachExample_Ext_DW.is_MissionPhaseStates =
        DockingApproachExa_IN_Disengage;
    } else {
      if (DockingApproachExample_Ext_U.StageTransition == 10) {
        /* Transition: '<S1>:178' */
        /* JointMission */
        DockingApproachExample_Ext_DW.is_MissionPhaseStates =
          DockingApproach_IN_JointMission;

        /* Entry 'JointMission': '<S1>:63' */
        DockingApproachExample_Ext_Y.JointMission = TRUE;
      }
    }
    break;

   case DockingApproach_IN_LatchCapture:
    /* During 'LatchCapture': '<S1>:385' */
    if (DockingApproachExample_Ext_DW.is_active_LatchCaptureCheck != 0U) {
      /* During 'LatchCaptureCheck': '<S1>:390' */
      /* 9 */
      u = DockingApproachExample_Ext_DW.LatchCapture_timer + 1;
      if (u <= 9) {
        DockingApproachExample_Ext_DW.LatchCapture_timer = (int8_T)u;
      } else {
        DockingApproachExample_Ext_DW.LatchCapture_timer = 9;
      }

      switch (DockingApproachExample_Ext_DW.is_LatchCaptureCheck) {
       case DockingAppro_IN_CheckLatchMated:
        /* During 'CheckLatchMated': '<S1>:400' */
        if (DockingApproachExample_Ext_DW.latch_status ==
            DockingApproachExample_Ex_MATED) {
          /* Transition: '<S1>:394' */
          DockingApproachExample_Ext_DW.is_LatchCaptureCheck =
            DockingApproachExampl_IN_Docked;

          /* Entry 'Docked': '<S1>:402' */
          DockingApproachExample_Ext_Y.LatchCaptureComplete = TRUE;
        } else if ((DockingApproachExample_Ext_DW.latch_status ==
                    DockingApproac_CLOSEDBUTUNMATED) ||
                   (DockingApproachExample_Ext_DW.LatchCapture_timer ==
                    LatchCapture_timer_upper_limit)) {
          /* Transition: '<S1>:396' */
          /* Transition: '<S1>:395' */
          /* Transition: '<S1>:398' */
          DockingApproachExample_Ext_DW.is_LatchCaptureCheck =
            DockingApproachE_IN_LatchFailed;
        } else {
          /* 9 */
        }
        break;

       case DockingApproa_IN_CheckLatchOpen:
        /* During 'CheckLatchOpen': '<S1>:399' */
        if (DockingApproachExample_Ext_DW.latch_status ==
            DockingApproachExample_Ext_OPEN) {
          /* Transition: '<S1>:393' */
          DockingApproachExample_Ext_DW.is_LatchCaptureCheck =
            DockingAppro_IN_CheckLatchMated;
        } else {
          /* 9 */
          if (DockingApproachExample_Ext_DW.LatchCapture_timer ==
              LatchCapture_timer_upper_limit) {
            /* Transition: '<S1>:397' */
            DockingApproachExample_Ext_DW.is_LatchCaptureCheck =
              DockingApproachE_IN_LatchFailed;
          }
        }
        break;

       case DockingApproachExampl_IN_Docked:
        /* During 'Docked': '<S1>:402' */
        /* Transition: '<S1>:389' */
        /* Docked */
        /* Exit Internal 'LatchCapture': '<S1>:385' */
        /* Exit Internal 'latch': '<S1>:403' */
        DockingApproachExample_Ext_DW.is_latch = DockingAppro_IN_NO_ACTIVE_CHILD;
        DockingApproachExample_Ext_DW.is_active_latch = 0U;

        /* Exit Internal 'LatchCaptureCheck': '<S1>:390' */
        DockingApproachExample_Ext_DW.is_LatchCaptureCheck =
          DockingAppro_IN_NO_ACTIVE_CHILD;
        if (DockingApproachExample_Ext_DW.is_active_LatchCaptureCheck != 0U) {
          /* Exit 'LatchCaptureCheck': '<S1>:390' */
          DockingApproachExample_Ext_Y.AttemptingToDock = FALSE;
          DockingApproachExample_Ext_DW.is_active_LatchCaptureCheck = 0U;
        }

        DockingApproachExample_Ext_DW.is_MissionPhaseStates =
          DockingApproa_IN_JointStabilize;
        break;

       case DockingApproachE_IN_LatchFailed:
        /* During 'LatchFailed': '<S1>:401' */
        /* Transition: '<S1>:387' */
        /* LatchFailed */
        /* Exit Internal 'LatchCapture': '<S1>:385' */
        /* Exit Internal 'latch': '<S1>:403' */
        DockingApproachExample_Ext_DW.is_latch = DockingAppro_IN_NO_ACTIVE_CHILD;
        DockingApproachExample_Ext_DW.is_active_latch = 0U;

        /* Exit Internal 'LatchCaptureCheck': '<S1>:390' */
        DockingApproachExample_Ext_DW.is_LatchCaptureCheck =
          DockingAppro_IN_NO_ACTIVE_CHILD;
        if (DockingApproachExample_Ext_DW.is_active_LatchCaptureCheck != 0U) {
          /* Exit 'LatchCaptureCheck': '<S1>:390' */
          DockingApproachExample_Ext_Y.AttemptingToDock = FALSE;
          DockingApproachExample_Ext_DW.is_active_LatchCaptureCheck = 0U;
        }

        DockingApproachExample_Ext_DW.is_MissionPhaseStates =
          DockingAppro_IN_DockingApproach;

        /* Entry 'DockingApproach': '<S1>:19' */
        DockingApproachExample_Ext_Y.DockingApproach = TRUE;
        DockingApproachExample_Ext_Y.DockingApproachComplete = FALSE;
        DockingApproachExample_Ext_DW.is_active_DockingApproach = 1U;
        if (DockingApproachExample_Ext_DW.is_DockingApproach !=
            Doc_IN_CheckTargetRelativeState) {
          DockingApproachExample_Ext_DW.is_DockingApproach =
            Doc_IN_CheckTargetRelativeState;

          /* Entry 'CheckTargetRelativeState': '<S1>:24' */
          /*  missionState.compute (...)  */
        }

        DockingApproachExample_Ext_DW.is_active_dockingSensor = 1U;

        /* Entry 'dockingSensor': '<S1>:28' */
        /* Entry Internal 'dockingSensor': '<S1>:28' */
        /* Transition: '<S1>:107' */
        if (DockingApproachExample_Ext_DW.is_dockingSensor !=
            DockingApproachExa_IN_Acquiring) {
          DockingApproachExample_Ext_DW.is_dockingSensor =
            DockingApproachExa_IN_Acquiring;

          /* Entry 'Acquiring': '<S1>:23' */
          DockingApproachExample_Ext_DW.dockingSensor_RelativePosition =
            DockingApproachExample_Ext_NONE;
          DockingApproachExample_Ext_DW.dockingSensor_RelativeVelocity =
            DockingApproachExample_Ext_NONE;
          DockingApproachExample_Ext_DW.dockingSensor_RelativeAttitude =
            DockingApproachExample_Ext_NONE;
          DockingApproachExample_Ext_DW.dockingSensor_targetState =
            DockingApproachExample_Ext_NONE;
        }
        break;

       default:
        DockingApproachExample_Ext_DW.is_LatchCaptureCheck =
          DockingAppro_IN_NO_ACTIVE_CHILD;
        break;
      }
    }

    if (!((DockingApproachExample_Ext_DW.is_MissionPhaseStates !=
           DockingApproach_IN_LatchCapture) ||
          (DockingApproachExample_Ext_DW.is_active_latch == 0U))) {
      /* During 'latch': '<S1>:403' */
      switch (DockingApproachExample_Ext_DW.is_latch) {
       case DockingAppr_IN_ClosedButUnmated:
        /* During 'ClosedButUnmated': '<S1>:419' */
        /* Transition: '<S1>:414' */
        /* Transition: '<S1>:406' */
        DockingApproachExample_Ext_DW.is_latch = DockingApproachExamp_IN_Opening;

        /* Entry 'Opening': '<S1>:415' */
        DockingApproachExample_Ext_DW.latch_status =
          DockingApproachEx_INDETERMINATE;
        break;

       case DockingApproachExamp_IN_Closing:
        /* During 'Closing': '<S1>:417' */
        /* Transition: '<S1>:411' */
        /* mated */
        DockingApproachExample_Ext_DW.is_latch = DockingApproachExample_IN_Mated;

        /* Entry 'Mated': '<S1>:418' */
        DockingApproachExample_Ext_DW.latch_status =
          DockingApproachExample_Ex_MATED;
        break;

       case DockingApproachExample_IN_Mated:
        /* During 'Mated': '<S1>:418' */
        /* Transition: '<S1>:413' */
        /* openLatch */
        /* Transition: '<S1>:406' */
        DockingApproachExample_Ext_DW.is_latch = DockingApproachExamp_IN_Opening;

        /* Entry 'Opening': '<S1>:415' */
        DockingApproachExample_Ext_DW.latch_status =
          DockingApproachEx_INDETERMINATE;
        break;

       case DockingApproachExample__IN_Open:
        /* During 'Open': '<S1>:416' */
        /* Transition: '<S1>:409' */
        /* closeLatch */
        DockingApproachExample_Ext_DW.is_latch = DockingApproachExamp_IN_Closing;

        /* Entry 'Closing': '<S1>:417' */
        DockingApproachExample_Ext_DW.latch_status =
          DockingApproachEx_INDETERMINATE;
        break;

       case DockingApproachExamp_IN_Opening:
        /* During 'Opening': '<S1>:415' */
        /* Transition: '<S1>:408' */
        /* open */
        DockingApproachExample_Ext_DW.is_latch = DockingApproachExample__IN_Open;

        /* Entry 'Open': '<S1>:416' */
        DockingApproachExample_Ext_DW.latch_status =
          DockingApproachExample_Ext_OPEN;
        break;

       default:
        DockingApproachExample_Ext_DW.is_latch = DockingAppro_IN_NO_ACTIVE_CHILD;
        break;
      }
    }
    break;

   case DockingA_IN_ProximityOperations:
    /* During 'ProximityOperations': '<S1>:64' */
    if (DockingApproachExample_Ext_U.StageTransition == 1) {
      /* Transition: '<S1>:140' */
      DockingApproachExample_Ext_Y.ApproachOrbitComplete = FALSE;

      /* FailedProximityApproach */
      DockingApproachExample_Ext_DW.is_MissionPhaseStates =
        DockingApproac_IN_ApproachOrbit;
    } else {
      if (DockingApproachExample_Ext_U.StageTransition == 3) {
        /* Transition: '<S1>:172' */
        DockingApproachExample_Ext_Y.ProximityOperationsComplete = TRUE;

        /* isInSight */
        DockingApproachExample_Ext_DW.is_MissionPhaseStates =
          DockingApproachE_IN_FarApproach;
      }
    }
    break;

   case DockingApproachExample_IN_Start:
    /* During 'Start': '<S1>:67' */
    if (DockingApproachExample_Ext_U.StageTransition == 0) {
      /* Transition: '<S1>:175' */
      /* Approach */
      DockingApproachExample_Ext_DW.is_MissionPhaseStates =
        DockingApproac_IN_ApproachOrbit;
    }
    break;

   default:
    DockingApproachExample_Ext_DW.is_MissionPhaseStates =
      DockingAppro_IN_NO_ACTIVE_CHILD;
    break;
  }
}

/* Model output function */
static void DockingApproachExample_Ext_output(void)
{
  /* Chart: '<Root>/Chart' */
  /* Gateway: Chart */
  DockingApproachExample_Ext_DW.sfEvent = DockingApproachExamp_CALL_EVENT;

  /* During: Chart */
  if (DockingApproachExample_Ext_DW.is_active_c1_DockingApproachExa == 0U) {
    /* Entry: Chart */
    DockingApproachExample_Ext_DW.is_active_c1_DockingApproachExa = 1U;

    /* Entry Internal: Chart */
    DockingApproachExample_Ext_DW.is_active_MissionPhaseStates = 1U;

    /* Entry Internal 'MissionPhaseStates': '<S1>:44' */
    /* Transition: '<S1>:138' */
    DockingApproachExample_Ext_DW.is_MissionPhaseStates =
      DockingApproachExample_IN_Start;
    DockingApproachExample_Ext_DW.is_active_thrust = 1U;
    DockingApproachExample_Ext_DW.is_active_fuel = 1U;
  } else {
    if (DockingApproachExample_Ext_DW.is_active_MissionPhaseStates != 0U) {
      DockingAppro_MissionPhaseStates();
    }
  }

  /* End of Chart: '<Root>/Chart' */
}

/* Model update function */
static void DockingApproachExample_Ext_update(void)
{
  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++DockingApproachExample_Ext_M->Timing.clockTick0)) {
    ++DockingApproachExample_Ext_M->Timing.clockTickH0;
  }

  DockingApproachExample_Ext_M->Timing.t[0] =
    DockingApproachExample_Ext_M->Timing.clockTick0 *
    DockingApproachExample_Ext_M->Timing.stepSize0 +
    DockingApproachExample_Ext_M->Timing.clockTickH0 *
    DockingApproachExample_Ext_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
void DockingApproachExample_Ext_initialize(void)
{
  /* InitializeConditions for Chart: '<Root>/Chart' */
  DockingApproachExample_Ext_DW.sfEvent = DockingApproachExamp_CALL_EVENT;
  DockingApproachExample_Ext_DW.is_active_MissionPhaseStates = 0U;
  DockingApproachExample_Ext_DW.is_MissionPhaseStates =
    DockingAppro_IN_NO_ACTIVE_CHILD;
  DockingApproachExample_Ext_DW.is_active_CaptureApproach = 0U;
  DockingApproachExample_Ext_DW.is_CaptureApproach =
    DockingAppro_IN_NO_ACTIVE_CHILD;
  DockingApproachExample_Ext_DW.is_active_OrbitalState_Active = 0U;
  DockingApproachExample_Ext_DW.is_active_GPS = 0U;
  DockingApproachExample_Ext_DW.is_GPS = DockingAppro_IN_NO_ACTIVE_CHILD;
  DockingApproachExample_Ext_DW.is_active_InertialNavigation = 0U;
  DockingApproachExample_Ext_DW.is_InertialNavigation =
    DockingAppro_IN_NO_ACTIVE_CHILD;
  DockingApproachExample_Ext_DW.is_active_OrbitalState_Complex = 0U;
  DockingApproachExample_Ext_DW.is_active_OrbitalState = 0U;
  DockingApproachExample_Ext_DW.is_OrbitalState =
    DockingAppro_IN_NO_ACTIVE_CHILD;
  DockingApproachExample_Ext_DW.is_active_OrbitalState2 = 0U;
  DockingApproachExample_Ext_DW.is_OrbitalState2 =
    DockingAppro_IN_NO_ACTIVE_CHILD;
  DockingApproachExample_Ext_DW.is_active_StarPlanetTracker = 0U;
  DockingApproachExample_Ext_DW.is_StarPlanetTracker =
    DockingAppro_IN_NO_ACTIVE_CHILD;
  DockingApproachExample_Ext_DW.is_active_DockingApproach = 0U;
  DockingApproachExample_Ext_DW.is_DockingApproach =
    DockingAppro_IN_NO_ACTIVE_CHILD;
  DockingApproachExample_Ext_DW.is_active_dockingSensor = 0U;
  DockingApproachExample_Ext_DW.is_dockingSensor =
    DockingAppro_IN_NO_ACTIVE_CHILD;
  DockingApproachExample_Ext_DW.is_active_LatchCaptureCheck = 0U;
  DockingApproachExample_Ext_DW.is_LatchCaptureCheck =
    DockingAppro_IN_NO_ACTIVE_CHILD;
  DockingApproachExample_Ext_DW.is_active_latch = 0U;
  DockingApproachExample_Ext_DW.is_latch = DockingAppro_IN_NO_ACTIVE_CHILD;
  DockingApproachExample_Ext_DW.is_active_fuel = 0U;
  DockingApproachExample_Ext_DW.is_active_thrust = 0U;
  DockingApproachExample_Ext_DW.is_active_c1_DockingApproachExa = 0U;
  DockingApproachExample_Ext_DW.OrbitalState_Position = 0;
  DockingApproachExample_Ext_DW.OrbitalState_Velocity = 0;
  DockingApproachExample_Ext_DW.OrbitalState_Attitude = 0;
  DockingApproachExample_Ext_DW.OrbitalState_Time = 0;
  DockingApproachExample_Ext_DW.InertialNavigation_AbsolutePosi = 0;
  DockingApproachExample_Ext_DW.InertialNavigation_AbsoluteAtti = 0;
  DockingApproachExample_Ext_DW.InertialNavigation_AbsoluteVelo = 0;
  DockingApproachExample_Ext_DW.GPS_AbsoluteVelocity = 0;
  DockingApproachExample_Ext_DW.GPS_AbsoluteTime = 0;
  DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteAttit = 0;
  DockingApproachExample_Ext_DW.StarPlanetTracker_AbsolutePosit = 0;
  DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteTime = 0;
  DockingApproachExample_Ext_DW.StarPlanetTracker_AbsoluteVeloc = 0;
  DockingApproachExample_Ext_DW.GPS_AbsolutePosition = 0;
  DockingApproachExample_Ext_DW.dockingSensor_RelativePosition = 0;
  DockingApproachExample_Ext_DW.dockingSensor_RelativeVelocity = 0;
  DockingApproachExample_Ext_DW.dockingSensor_RelativeAttitude = 0;
  DockingApproachExample_Ext_DW.dockingSensor_targetState = 0;
  DockingApproachExample_Ext_DW.thrust_status = 0;
  DockingApproachExample_Ext_DW.fuel_status = 0;
  DockingApproachExample_Ext_DW.DockingApproach_timer = 0;
  DockingApproachExample_Ext_DW.CaptureApproach_timer = 0;
  DockingApproachExample_Ext_DW.latch_status = 0;
  DockingApproachExample_Ext_DW.LatchCapture_timer = 0;
  DockingApproachExample_Ext_DW.dockingSensor_timer = 0;
  DockingApproachExample_Ext_DW.InertialNavigation_timer = 0;
  DockingApproachExample_Ext_DW.StarPlanetTracker_timer = 0;
  DockingApproachExample_Ext_DW.GPS_timer = 0;
  DockingApproachExample_Ext_DW.VALID = FALSE;

  /* InitializeConditions for Outport: '<Root>/CaptureApproachComplete' incorporates:
   *  InitializeConditions for Chart: '<Root>/Chart'
   */
  DockingApproachExample_Ext_Y.CaptureApproachComplete = FALSE;

  /* InitializeConditions for Outport: '<Root>/DockingApproachComplete' incorporates:
   *  InitializeConditions for Chart: '<Root>/Chart'
   */
  DockingApproachExample_Ext_Y.DockingApproachComplete = FALSE;

  /* InitializeConditions for Outport: '<Root>/AttemptingToDock' incorporates:
   *  InitializeConditions for Chart: '<Root>/Chart'
   */
  DockingApproachExample_Ext_Y.AttemptingToDock = FALSE;

  /* InitializeConditions for Outport: '<Root>/LatchCaptureComplete' incorporates:
   *  InitializeConditions for Chart: '<Root>/Chart'
   */
  DockingApproachExample_Ext_Y.LatchCaptureComplete = FALSE;

  /* InitializeConditions for Outport: '<Root>/DockingApproach' incorporates:
   *  InitializeConditions for Chart: '<Root>/Chart'
   */
  DockingApproachExample_Ext_Y.DockingApproach = FALSE;

  /* InitializeConditions for Outport: '<Root>/ApproachOrbitComplete' incorporates:
   *  InitializeConditions for Chart: '<Root>/Chart'
   */
  DockingApproachExample_Ext_Y.ApproachOrbitComplete = FALSE;

  /* InitializeConditions for Outport: '<Root>/FarApproachComplete' incorporates:
   *  InitializeConditions for Chart: '<Root>/Chart'
   */
  DockingApproachExample_Ext_Y.FarApproachComplete = FALSE;

  /* InitializeConditions for Outport: '<Root>/ProximityOperationsComplete' incorporates:
   *  InitializeConditions for Chart: '<Root>/Chart'
   */
  DockingApproachExample_Ext_Y.ProximityOperationsComplete = FALSE;

  /* InitializeConditions for Outport: '<Root>/FailedApproach' incorporates:
   *  InitializeConditions for Chart: '<Root>/Chart'
   */
  DockingApproachExample_Ext_Y.FailedApproach = FALSE;

  /* InitializeConditions for Outport: '<Root>/JointMission' incorporates:
   *  InitializeConditions for Chart: '<Root>/Chart'
   */
  DockingApproachExample_Ext_Y.JointMission = FALSE;

  /* InitializeConditions for Outport: '<Root>/CaptureApproachFailed' incorporates:
   *  InitializeConditions for Chart: '<Root>/Chart'
   */
  DockingApproachExample_Ext_Y.CaptureApproachFailed = FALSE;
}

/* Model terminate function */
void DockingApproachExample_Ext_terminate(void)
{
  /* (no terminate code required) */
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/
void MdlOutputs(int_T tid)
{
  DockingApproachExample_Ext_output();

  /* tid is required for a uniform function interface.
   * Argument tid is not used in the function. */
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  DockingApproachExample_Ext_update();

  /* tid is required for a uniform function interface.
   * Argument tid is not used in the function. */
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  DockingApproachExample_Ext_initialize();
}

void MdlTerminate(void)
{
  DockingApproachExample_Ext_terminate();
}

/* Registration function */
RT_MODEL_DockingApproachExamp_T *DockingApproachExample_Ext(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  // XXX: Initializing global memory to zero: Unnecessary!
  /*(void) memset((void *)DockingApproachExample_Ext_M, 0,
                sizeof(RT_MODEL_DockingApproachExamp_T));*/

  /* Initialize timing info */
  {
    int_T *mdlTsMap = DockingApproachExample_Ext_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    DockingApproachExample_Ext_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    DockingApproachExample_Ext_M->Timing.sampleTimes =
      (&DockingApproachExample_Ext_M->Timing.sampleTimesArray[0]);
    DockingApproachExample_Ext_M->Timing.offsetTimes =
      (&DockingApproachExample_Ext_M->Timing.offsetTimesArray[0]);

    /* task periods */
    DockingApproachExample_Ext_M->Timing.sampleTimes[0] = (1.0);

    /* task offsets */
    DockingApproachExample_Ext_M->Timing.offsetTimes[0] = (0.0);
  }

  rtmSetTPtr(DockingApproachExample_Ext_M,
             &DockingApproachExample_Ext_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = DockingApproachExample_Ext_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    DockingApproachExample_Ext_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(DockingApproachExample_Ext_M, 300.0);
  DockingApproachExample_Ext_M->Timing.stepSize0 = 1.0;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    DockingApproachExample_Ext_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(DockingApproachExample_Ext_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(DockingApproachExample_Ext_M->rtwLogInfo, (NULL));
    rtliSetLogT(DockingApproachExample_Ext_M->rtwLogInfo, "tout");
    rtliSetLogX(DockingApproachExample_Ext_M->rtwLogInfo, "");
    rtliSetLogXFinal(DockingApproachExample_Ext_M->rtwLogInfo, "");
    rtliSetSigLog(DockingApproachExample_Ext_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(DockingApproachExample_Ext_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(DockingApproachExample_Ext_M->rtwLogInfo, 0);
    rtliSetLogMaxRows(DockingApproachExample_Ext_M->rtwLogInfo, 1000);
    rtliSetLogDecimation(DockingApproachExample_Ext_M->rtwLogInfo, 1);

    /*
     * Set pointers to the data and signal info for each output
     */
    {
      static void * rt_LoggedOutputSignalPtrs[] = {
        &DockingApproachExample_Ext_Y.CaptureApproachComplete,
        &DockingApproachExample_Ext_Y.DockingApproachComplete,
        &DockingApproachExample_Ext_Y.AttemptingToDock,
        &DockingApproachExample_Ext_Y.LatchCaptureComplete,
        &DockingApproachExample_Ext_Y.DockingApproach,
        &DockingApproachExample_Ext_Y.ApproachOrbitComplete,
        &DockingApproachExample_Ext_Y.FarApproachComplete,
        &DockingApproachExample_Ext_Y.ProximityOperationsComplete,
        &DockingApproachExample_Ext_Y.FailedApproach,
        &DockingApproachExample_Ext_Y.JointMission,
        &DockingApproachExample_Ext_Y.CaptureApproachFailed
      };

      rtliSetLogYSignalPtrs(DockingApproachExample_Ext_M->rtwLogInfo,
                            ((LogSignalPtrsType)rt_LoggedOutputSignalPtrs));
    }

    {
      static int_T rt_LoggedOutputWidths[] = {
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1
      };

      static int_T rt_LoggedOutputNumDimensions[] = {
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1
      };

      static int_T rt_LoggedOutputDimensions[] = {
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1,
        1
      };

      static boolean_T rt_LoggedOutputIsVarDims[] = {
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0
      };

      static void* rt_LoggedCurrentSignalDimensions[] = {
        (NULL),
        (NULL),
        (NULL),
        (NULL),
        (NULL),
        (NULL),
        (NULL),
        (NULL),
        (NULL),
        (NULL),
        (NULL)
      };

      static int_T rt_LoggedCurrentSignalDimensionsSize[] = {
        4,
        4,
        4,
        4,
        4,
        4,
        4,
        4,
        4,
        4,
        4
      };

      static BuiltInDTypeId rt_LoggedOutputDataTypeIds[] = {
        SS_BOOLEAN,
        SS_BOOLEAN,
        SS_BOOLEAN,
        SS_BOOLEAN,
        SS_BOOLEAN,
        SS_BOOLEAN,
        SS_BOOLEAN,
        SS_BOOLEAN,
        SS_BOOLEAN,
        SS_BOOLEAN,
        SS_BOOLEAN
      };

      static int_T rt_LoggedOutputComplexSignals[] = {
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0
      };

      static const char_T *rt_LoggedOutputLabels[] = {
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        "" };

      static const char_T *rt_LoggedOutputBlockNames[] = {
        "DockingApproachExample_Ext/CaptureApproachComplete",
        "DockingApproachExample_Ext/DockingApproachComplete",
        "DockingApproachExample_Ext/AttemptingToDock",
        "DockingApproachExample_Ext/LatchCaptureComplete",
        "DockingApproachExample_Ext/DockingApproach",
        "DockingApproachExample_Ext/ApproachOrbitComplete",
        "DockingApproachExample_Ext/FarApproachComplete",
        "DockingApproachExample_Ext/ProximityOperationsComplete",
        "DockingApproachExample_Ext/FailedApproach",
        "DockingApproachExample_Ext/JointMission",
        "DockingApproachExample_Ext/CaptureApproachFailed" };

      static RTWLogDataTypeConvert rt_RTWLogDataTypeConvert[] = {
        { 0, SS_BOOLEAN, SS_BOOLEAN, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_BOOLEAN, SS_BOOLEAN, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_BOOLEAN, SS_BOOLEAN, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_BOOLEAN, SS_BOOLEAN, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_BOOLEAN, SS_BOOLEAN, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_BOOLEAN, SS_BOOLEAN, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_BOOLEAN, SS_BOOLEAN, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_BOOLEAN, SS_BOOLEAN, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_BOOLEAN, SS_BOOLEAN, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_BOOLEAN, SS_BOOLEAN, 0, 0, 0, 1.0, 0, 0.0 },

        { 0, SS_BOOLEAN, SS_BOOLEAN, 0, 0, 0, 1.0, 0, 0.0 }
      };

      static RTWLogSignalInfo rt_LoggedOutputSignalInfo[] = {
        {
          11,
          rt_LoggedOutputWidths,
          rt_LoggedOutputNumDimensions,
          rt_LoggedOutputDimensions,
          rt_LoggedOutputIsVarDims,
          rt_LoggedCurrentSignalDimensions,
          rt_LoggedCurrentSignalDimensionsSize,
          rt_LoggedOutputDataTypeIds,
          rt_LoggedOutputComplexSignals,
          (NULL),

          { rt_LoggedOutputLabels },
          (NULL),
          (NULL),
          (NULL),

          { rt_LoggedOutputBlockNames },

          { (NULL) },
          (NULL),
          rt_RTWLogDataTypeConvert
        }
      };

      rtliSetLogYSignalInfo(DockingApproachExample_Ext_M->rtwLogInfo,
                            rt_LoggedOutputSignalInfo);

      /* set currSigDims field */
      rt_LoggedCurrentSignalDimensions[0] = &rt_LoggedOutputWidths[0];
      rt_LoggedCurrentSignalDimensions[1] = &rt_LoggedOutputWidths[1];
      rt_LoggedCurrentSignalDimensions[2] = &rt_LoggedOutputWidths[2];
      rt_LoggedCurrentSignalDimensions[3] = &rt_LoggedOutputWidths[3];
      rt_LoggedCurrentSignalDimensions[4] = &rt_LoggedOutputWidths[4];
      rt_LoggedCurrentSignalDimensions[5] = &rt_LoggedOutputWidths[5];
      rt_LoggedCurrentSignalDimensions[6] = &rt_LoggedOutputWidths[6];
      rt_LoggedCurrentSignalDimensions[7] = &rt_LoggedOutputWidths[7];
      rt_LoggedCurrentSignalDimensions[8] = &rt_LoggedOutputWidths[8];
      rt_LoggedCurrentSignalDimensions[9] = &rt_LoggedOutputWidths[9];
      rt_LoggedCurrentSignalDimensions[10] = &rt_LoggedOutputWidths[10];
    }

    rtliSetLogY(DockingApproachExample_Ext_M->rtwLogInfo, "yout");
  }

  DockingApproachExample_Ext_M->solverInfoPtr =
    (&DockingApproachExample_Ext_M->solverInfo);
  DockingApproachExample_Ext_M->Timing.stepSize = (1.0);
  rtsiSetFixedStepSize(&DockingApproachExample_Ext_M->solverInfo, 1.0);
  rtsiSetSolverMode(&DockingApproachExample_Ext_M->solverInfo,
                    SOLVER_MODE_SINGLETASKING);

  /* states (dwork) */
  DockingApproachExample_Ext_M->ModelData.dwork = ((void *)
    &DockingApproachExample_Ext_DW);
  // XXX: Initializing global memory to zero: Unnecessary!
  /*(void) memset((void *)&DockingApproachExample_Ext_DW, 0,
                sizeof(DW_DockingApproachExample_Ext_T));*/

  /* external inputs */
  DockingApproachExample_Ext_M->ModelData.inputs = (((void*)
    &DockingApproachExample_Ext_U));
  // XXX: Initializing global memory to zero: Unnecessary!
  /*(void) memset((void *)&DockingApproachExample_Ext_U, 0,
                sizeof(ExtU_DockingApproachExample_E_T));*/

  /* external outputs */
  DockingApproachExample_Ext_M->ModelData.outputs =
    (&DockingApproachExample_Ext_Y);
  // XXX: Initializing global memory to zero: Unnecessary!
  /*(void) memset((void *)&DockingApproachExample_Ext_Y, 0,
                sizeof(ExtY_DockingApproachExample_E_T));*/

  /* Initialize Sizes */
  DockingApproachExample_Ext_M->Sizes.numContStates = (0);/* Number of continuous states */
  DockingApproachExample_Ext_M->Sizes.numY = (11);/* Number of model outputs */
  DockingApproachExample_Ext_M->Sizes.numU = (13);/* Number of model inputs */
  DockingApproachExample_Ext_M->Sizes.sysDirFeedThru = (1);/* The model is direct feedthrough */
  DockingApproachExample_Ext_M->Sizes.numSampTimes = (1);/* Number of sample times */
  DockingApproachExample_Ext_M->Sizes.numBlocks = (13);/* Number of blocks */
  DockingApproachExample_Ext_M->Sizes.numBlockIO = (11);/* Number of block outputs */
  return DockingApproachExample_Ext_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
