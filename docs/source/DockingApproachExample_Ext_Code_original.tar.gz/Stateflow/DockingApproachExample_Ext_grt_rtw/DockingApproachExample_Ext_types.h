/*
 * DockingApproachExample_Ext_types.h
 *
 * Code generation for model "DockingApproachExample_Ext".
 *
 * Model version              : 1.484
 * Simulink Coder version : 8.4 (R2013a) 13-Feb-2013
 * C source code generated on : Fri Dec 19 09:13:53 2014
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objective: Execution efficiency
 * Validation result: Not run
 */
#ifndef RTW_HEADER_DockingApproachExample_Ext_types_h_
#define RTW_HEADER_DockingApproachExample_Ext_types_h_

/* Forward declaration for rtModel */
typedef struct tag_RTM_DockingApproachExampl_T RT_MODEL_DockingApproachExamp_T;

#endif                                 /* RTW_HEADER_DockingApproachExample_Ext_types_h_ */
